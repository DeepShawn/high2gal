# 发布测试

这些脚本测试根目录 `index.html`。测试才需要Python Playwright和Chromium；正常打开游戏不需要依赖。

依次运行（请不要并行运行，以免共享结果文件相互覆盖）：

```sh
python tests/test_v39.py
python tests/test_extended39.py
python tests/test_flow39.py
python tests/test_regression39.py
python tests/test_release39.py
python tests/test_storage_real39.py
```

可以用环境变量 `CHROMIUM_BIN` 指定Chromium可执行文件。测试不会安装或下载浏览器。

`support.py` 为大部分检查提供手动动画时钟和内存localStorage，便于重建新文档验证恢复；它不能证明真实浏览器关闭后的磁盘持久化。`test_release39.py` 先用未经改写的HTML测试实际按钮、触屏模式与全屏，再单独打开测试接口检查棋规。`test_storage_real39.py` 是独立真实磁盘尝试，本发布环境被浏览器策略拦截。

`test_extended39.py` 从随包 `fixtures/v3.8.html` 生成真实旧版题目快照，再导入新版。随机课表的迁移夹具固定种子1234，确保包含体育课；没有假定每个随机日都一定有体育。

`school_driver39.js` 是知道答案、会即时应对危险的自动代理。它验证主线可达性，不代表真人能够用同样速度通关。新人物放学分支使用真实条件函数和正反边界夹具，没有宣称每条恋爱线都由真人从零好感完整游玩。

测试报告、JSON结果及截图随包提供。题库测试检查结构、ID、选项、分级预算等，不是教师逐题学科审校。
