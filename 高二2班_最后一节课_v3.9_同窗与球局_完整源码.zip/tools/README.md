# 构建材料

本目录是 `index.html` 的可编辑构建源，不是网页运行时依赖。所有文件为UTF-8。

`python tools/build.py`：以 `tests/fixtures/v3.8.html` 为基线，注入新题库、逻辑、界面、手机布局与翻译词典，输出根目录 `index.html`，并生成可用 `node --check tools/game39.js` 检查的内嵌脚本副本。

`python tools/generate_bank.py`：重建本版本新增的840条题目，写入 `questions39.json`、`grid39.json`、`bank39_summary.json`。这些题目包括参数变式；改过题库以后再运行build。全部Python构建脚本只依赖标准库。

| 文件 | 用途 |
|---|---|
| core39.js | 学习政策、选题、体育、人物互动、封存试炼、存档迁移与新增路线 |
| ui39.js | 设置、攻略、人物、教程和场景显示 |
| mobile39.js | 手机DOM重排、场景预览、还原电脑布局 |
| style39.css | 新角色、页面、手机触屏样式 |
| i18n39.js | 字形转换、本地英文词典与文本切换；英语旧长剧情仍部分保留中文 |
| data39.js | 新结局和成就定义 |
| questions39.json / grid39.json | 新增四选一／编号题目和英文文本 |

修改代码后，重新运行对应测试。测试依赖Python Playwright和Chromium，不属于游戏运行依赖。旧版基线仅用于重建和迁移测试；实际游玩始终使用根目录最新版。

随包说明和根目录 `题库.json` 是本次发布生成的文档快照，不会由 `build.py` 自动同步；改题时应同时更新答案、解析、分级说明与文档。
