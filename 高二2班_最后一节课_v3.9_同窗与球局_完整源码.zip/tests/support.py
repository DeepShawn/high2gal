"""Test support: Chromium DOM, manual clock, simulated localStorage reconstructed in a new document.
Only the source test flag / storage / animation clock are replaced. Ordinary game HTML is unchanged.
Fixtures verify serial state, not real persistent disk storage. No third-party runtime dependencies.
"""
import argparse, json, re, time, os, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT.joinpath('index.html').read_text(encoding='utf-8')
CHROMIUM_BIN=os.environ.get('CHROMIUM_BIN') or shutil.which('chromium') or shutil.which('chromium-browser')
RESULTS=[]
ERRORS=[]
T='__LAST_CLASS_TEST__'

def fixture(seed=None, persist=True, storage='ok', manual=True):
    src=SOURCE.replace("const testMode = new URLSearchParams(location.search).get('test') === '1';",'const testMode = true;')
    src=src.replace("const persistenceEnabled = !testMode || new URLSearchParams(location.search).get('persist') === '1';",f'const persistenceEnabled = {str(persist).lower()};')
    shim='''<script>window.__disk=SEED;window.__storageMode=MODE;
    Object.defineProperty(window,'localStorage',{value:{getItem(k){if(__storageMode==='denied')throw new DOMException('denied','SecurityError');return Object.hasOwn(__disk,k)?__disk[k]:null;},setItem(k,v){if(__storageMode!=='ok')throw new DOMException('full','QuotaExceededError');__disk[k]=String(v);},removeItem(k){delete __disk[k]},clear(){window.__disk={}}}});
    RAF
    </script>'''.replace('SEED',json.dumps(seed or {},ensure_ascii=False)).replace('MODE',json.dumps(storage)).replace('RAF','window.requestAnimationFrame=()=>0;' if manual else '')
    return src.replace('<script>',shim+'<script>',1)

class Harness:
    def __init__(self,ctx,legacy_start=True): self.ctx=ctx;self.page=None;self.legacy_start=legacy_start
    def fresh(self,seed=None,**kw):
        if self.page:self.page.close()
        self.page=self.ctx.new_page();self.page.set_default_timeout(4000);self.page.on('pageerror',lambda e:ERRORS.append(str(e)))
        self.page.set_content(fixture(seed,**kw))
        if self.legacy_start:self.ev('const start=T.start;T.start=(...args)=>{start(...args);T.enterCampus(1);};')
        return self.page
    def ev(self,code):return self.page.evaluate('(()=>{const T=window.__LAST_CLASS_TEST__;'+code+'})()')
    def start(self,mode='normal'):
        self.ev(f'T.start({json.dumps(mode)});T.finishDialogue();')
    def roundtrip(self):
        self.ev('T.autoSave("test boundary");')
        disk=self.page.evaluate('__disk')
        self.fresh(disk)
        self.ev('T.continueGame();')
        return self.ev('return {has:!!T.state,phase:T.state?.phase,modal:T.modal?.kind};')
    def valid(self):return self.ev('try{T.validateImport(T.exportData());return true;}catch(e){return e.message;}')
    def run(self,name,fn):
        print('BEGIN',name,flush=True)
        begin=time.time()
        try: fn();RESULTS.append({'name':name,'passed':True,'seconds':round(time.time()-begin,3)}); print('PASS',name,'%.2fs'%(time.time()-begin),flush=True)
        except Exception as e:
            RESULTS.append({'name':name,'passed':False,'error':str(e),'seconds':round(time.time()-begin,3)});print('FAIL',name,str(e),flush=True)
        ROOT.joinpath('tests/partial_results.json').write_text(json.dumps({'results':RESULTS,'pageErrors':ERRORS},ensure_ascii=False,indent=2))

def ensure(value,message='assertion failed'):
    if not value:raise AssertionError(message)

