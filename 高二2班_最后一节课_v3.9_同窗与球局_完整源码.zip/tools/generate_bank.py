"""Author deterministic, bilingual high-school practice variants; no network at runtime."""
from pathlib import Path
import json, math, random, collections
R=random.Random(3901)
BANK={s:[] for s in ['chinese','chemistry','biology','physics','english','math']}
SEEN=set()
GR={1:15,2:25,3:40,4:60}
def fmt(x):
    if isinstance(x,str):return x
    return f'{x:.6g}'
def put(s,t,correct,wrong,ex,topic,grade,en_t=None,en_correct=None,en_wrong=None,en_ex=None):
    if t in SEEN: raise ValueError('duplicate '+t)
    SEEN.add(t)
    opts=[str(correct)]+[str(x) for x in wrong]
    if len(opts)!=4 or len(set(opts))!=4:raise ValueError((t,opts))
    enopts=[str(en_correct if en_correct is not None else correct)]+[str(x) for x in (en_wrong if en_wrong is not None else wrong)]
    ix=list(range(4));R.shuffle(ix);ident=f'{s}-v39-{len(BANK[s])+1:03d}'
    q=dict(text=t,choices=[opts[i] for i in ix],answer=ix.index(0),explain=ex,topic37=topic,id37=ident,
           grade38=grade,normalSeconds38=GR[grade],grading38={1:'高中概念或公式的直接辨认。',2:'高中单一知识链的代入、换算或语境判断。',3:'结合两个以上条件，完成推理、比较或多步计算。',4:'阅读给定材料，结合证据完成综合推断。'}[grade],
           en39=dict(text=en_t or t,choices=[enopts[i] for i in ix],explain=en_ex or ex,topic=topic),
           author39='本作编写；参数变式不是新增知识点')
    BANK[s].append(q)
def num(s,t,ans,ex,topic,grade,en_t,en_ex,unit=''):
    vals=[]
    for x in [ans+1,ans*2,ans/2,ans+2,ans-1,ans+3,ans+5,ans*3]:
        v=fmt(x)+unit
        if v!=fmt(ans)+unit and v not in vals:vals.append(v)
        if len(vals)==3:break
    put(s,t,fmt(ans)+unit,vals,ex,topic,grade,en_t,en_ex=en_ex)
# Mathematics: 18 template families, ten distinct parameter instances each.
for k in range(1,11):
    a=k+1;b=k+2;n=k+3
    num('math',f'等差数列首项为{a}，公差为2，第{n}项为多少？',a+(n-1)*2,f'aₙ=a₁+(n−1)d={a}+({n}−1)×2={a+(n-1)*2}。','数列',2,f'An arithmetic sequence starts at {a} with common difference 2. Find term {n}.',f'a_n=a_1+(n-1)d={a+(n-1)*2}.')
    num('math',f'等差数列首项1、公差2，求前{n}项和。',n*n,f'Sₙ=n[2a₁+(n−1)d]/2={n}²={n*n}。','数列求和',2,f'Find the sum of the first {n} terms of 1, 3, 5, …',f'S_n=n[2+(n-1)2]/2=n²={n*n}.')
    num('math',f'等比数列首项3、公比2，第{k+1}项为多少？',3*2**k,f'aₙ=a₁qⁿ⁻¹=3×2^{k}={3*2**k}。','等比数列',2,f'A geometric sequence starts at 3 with ratio 2. Find term {k+1}.',f'a_n=3×2^{k}={3*2**k}.')
    num('math',f'f(x)={a}x²，求f′({k})。',2*a*k,f'f′(x)=2×{a}x，代入x={k}得{2*a*k}。','导数',2,f'f(x)={a}x². Find f′({k}).',f'f′(x)=2×{a}x, so f′({k})={2*a*k}.')
    num('math',f'f(x)=x³−{3*k*k}x，求f′({k})。',0,f'f′(x)=3x²−{3*k*k}，在x={k}时为0。','导数与驻点',2,f'f(x)=x³−{3*k*k}x. Find f′({k}).',f'f′(x)=3x²−{3*k*k}, which is 0 at x={k}.')
    num('math',f'二次函数y=(x−{k})²+{a}的最小值是多少？',a,f'平方项非负，x={k}时取最小值{a}。','二次函数',1,f'What is the minimum value of y=(x−{k})²+{a}?',f'The squared term is nonnegative; the minimum is {a}.')
    num('math',f'二次方程x²−{2*k}x+{k*k-1}=0的判别式是多少？',4,f'Δ=b²−4ac={4*k*k}−4×{k*k-1}=4。','判别式',2,f'Find the discriminant of x²−{2*k}x+{k*k-1}=0.',f'Δ=b²−4ac={4*k*k}−{4*(k*k-1)}=4.')
    num('math',f'已知log₂x={k}，求x。',2**k,f'由对数定义，x=2^{k}={2**k}。','对数',1,f'Given log₂x={k}, find x.',f'The definition of a logarithm gives x=2^{k}={2**k}.')
    num('math',f'向量a=({k},2)，b=(3,{a})，求a·b。',3*k+2*a,f'a·b={k}×3+2×{a}={3*k+2*a}。','平面向量',2,f'For vectors a=({k},2) and b=(3,{a}), find a·b.',f'The dot product is {k}×3+2×{a}={3*k+2*a}.')
    num('math',f'向量a=({k},1)、b=(2,m)互相垂直，求m。',-2*k,f'垂直时点积为0，2×{k}+m=0，m={-2*k}。','向量垂直',3,f'Vectors ({k},1) and (2,m) are perpendicular. Find m.',f'The dot product is zero: {2*k}+m=0, hence m={-2*k}.')
    num('math',f'点A=({k},{a})、B=({k+2},{a+6})所确定直线的斜率为多少？',3,'k=(y₂−y₁)/(x₂−x₁)=6/2=3。','直线',2,f'Find the slope through A=({k},{a}) and B=({k+2},{a+6}).','Slope = change in y / change in x = 6/2 = 3.')
    num('math',f'圆(x−{k})²+(y+2)²={a*a}的半径是多少？',a,f'标准方程右侧为r²，所以r={a}。','圆的方程',1,f'Find the radius of (x−{k})²+(y+2)²={a*a}.',f'The right side is r², so r={a}.')
    num('math',f'集合A有{k+3}个元素，B有{k+2}个元素，A∩B有{k}个元素。A∪B有几个元素？',k+5,f'|A∪B|=|A|+|B|−|A∩B|={k+3}+{k+2}−{k}={k+5}。','集合',2,f'|A|={k+3}, |B|={k+2}, |A∩B|={k}. Find |A∪B|.',f'Inclusion–exclusion gives {k+3}+{k+2}−{k}={k+5}.')
    num('math',f'从{k+3}名不同学生中选出2名代表，共有多少种选法？',(k+3)*(k+2)//2,f'C({k+3},2)=({k+3})({k+2})/2={(k+3)*(k+2)//2}。','组合',2,f'Choose 2 representatives from {k+3} different students. How many selections are possible?',f'C({k+3},2)={(k+3)*(k+2)//2}.')
    num('math',f'(1+x)^{k+2}中x²项的系数是多少？',(k+2)*(k+1)//2,f'二项式定理给出系数C({k+2},2)={(k+2)*(k+1)//2}。','二项式定理',2,f'Find the coefficient of x² in (1+x)^{k+2}.',f'The binomial theorem gives C({k+2},2)={(k+2)*(k+1)//2}.')
    num('math',f'随机变量X只取0和{k+1}，对应概率分别为0.6和0.4。求E(X)。',.4*(k+1),f'E(X)=0×0.6+{k+1}×0.4={fmt(.4*(k+1))}。','数学期望',2,f'X equals 0 with probability 0.6 and {k+1} with probability 0.4. Find E(X).',f'E(X)=0×0.6+{k+1}×0.4={fmt(.4*(k+1))}.')
    num('math',f'椭圆x²/{(k+2)**2}+y²/{(k+2)**2-1}=1，焦距为多少？',2,f'a²−b²=1，c=1，焦距2c=2。','椭圆',3,f'For x²/{(k+2)**2}+y²/{(k+2)**2-1}=1, find the distance between the foci.','c²=a²−b²=1, so 2c=2.')
    num('math',f'等差数列满足a₃={k+4}、a₇={k+12}，求公差。',2,f'a₇−a₃=4d=8，所以d=2。','数列条件推理',3,f'An arithmetic sequence has a₃={k+4} and a₇={k+12}. Find its common difference.','a₇−a₃=4d=8, so d=2.')
# Physics, all assumptions explicit and SI dimensions retained.
for k in range(1,11):
    m=k+1;t=k+2;v=k+3
    num('physics',f'质量{m}kg的物体受到{3*m}N的水平合外力，求加速度大小。',3,'由牛顿第二定律a=F合/m=3m/m=3m/s²。','牛顿第二定律',1,f'A {m} kg body has a net horizontal force of {3*m} N. Find its acceleration.','Newton’s second law: a=F_net/m=3 m/s².',' m/s²')
    num('physics',f'物体从静止开始以2m/s²做匀加速直线运动，{t}s内的位移为多少？',t*t,f'x=at²/2={t}²={t*t}m。','匀变速运动',2,f'A body starts from rest with constant acceleration 2 m/s². Find its displacement in {t} s.',f'x=at²/2={t*t} m.',' m')
    num('physics',f'质量2kg的物体以{v}m/s运动，动能为多少？',v*v,f'Eₖ=mv²/2={v*v}J。','动能',1,f'A 2 kg body moves at {v} m/s. Find its kinetic energy.',f'E_k=mv²/2={v*v} J.',' J')
    num('physics',f'质量{m}kg的物体以4m/s向东运动，其动量大小为多少？',4*m,f'p=mv={m}×4={4*m}kg·m/s。','动量',1,f'A {m} kg object travels east at 4 m/s. Find its momentum magnitude.',f'p=mv={4*m} kg·m/s.',' kg·m/s')
    num('physics',f'轻弹簧劲度系数{100*k}N/m，处于弹性限度内伸长0.02m，弹力大小为多少？',2*k,f'胡克定律F=kx={100*k}×0.02={2*k}N。','弹力',1,f'A light spring has spring constant {100*k} N/m and is stretched 0.02 m within its elastic limit. Find the force.',f'Hooke’s law: F=kx={2*k} N.',' N')
    num('physics',f'取g=10m/s²，把质量{m}kg的物体缓慢提升3m，重力势能增加多少？',30*m,f'ΔEₚ=mgh={m}×10×3={30*m}J。','重力势能',2,f'Take g=10 m/s². A {m} kg body is slowly raised 3 m. Find the increase in gravitational potential energy.',f'ΔE_p=mgh={30*m} J.',' J')
    num('physics',f'电阻{2*k}Ω两端电压{6*k}V，流过电阻的电流为多少？',3,f'I=U/R={6*k}/{2*k}=3A。','欧姆定律',1,f'A {2*k} Ω resistor has a voltage of {6*k} V across it. Find the current.','I=V/R=3 A.',' A')
    num('physics',f'纯电阻电路中U={4*k}V，I=2A，电功率为多少？',8*k,f'P=UI={4*k}×2={8*k}W。','电功率',1,f'A resistive circuit has V={4*k} V and I=2 A. Find its power.',f'P=VI={8*k} W.',' W')
    num('physics',f'电阻2Ω中通有3A恒定电流，{t}s内产生多少焦耳热？',18*t,f'Q=I²Rt=3²×2×{t}={18*t}J。','焦耳定律',2,f'A constant current of 3 A flows through a 2 Ω resistor for {t} s. Find the heat produced.',f'Q=I²Rt={18*t} J.',' J')
    num('physics',f'某波的频率为{2*k}Hz、波长为3m，波速为多少？',6*k,f'v=fλ={2*k}×3={6*k}m/s。','机械波',1,f'A wave has frequency {2*k} Hz and wavelength 3 m. Find its speed.',f'v=fλ={6*k} m/s.',' m/s')
    num('physics',f'电容为{k}μF的电容器加上6V电压，所带电荷量为多少？',6*k,f'Q=CU={k}μF×6V={6*k}μC。','电容',2,f'A {k} μF capacitor has a voltage of 6 V. Find the stored charge.',f'Q=CV={6*k} μC.',' μC')
    num('physics',f'{10*k}匝线圈每匝磁通量在0.2s内均匀变化0.04Wb，感应电动势大小是多少？',2*k,f'|E|=N|ΔΦ/Δt|={10*k}×0.04/0.2={2*k}V。','电磁感应',2,f'A coil has {10*k} turns. Flux per turn changes uniformly by 0.04 Wb in 0.2 s. Find the induced emf magnitude.',f'|E|=N|ΔΦ/Δt|={2*k} V.',' V')
    num('physics',f'电量2C的粒子以{k}m/s垂直射入0.5T匀强磁场，洛伦兹力大小为多少？',k,f'v⊥B，F=qvB=2×{k}×0.5={k}N。','磁场力',2,f'A particle of charge 2 C travels at {k} m/s perpendicular to a uniform 0.5 T magnetic field. Find the magnetic force magnitude.',f'F=qvB={k} N.',' N')
    num('physics',f'质量2kg的物体以{v}m/s做半径2m的匀速圆周运动，所需向心力是多少？',v*v,f'F=mv²/r=2×{v}²/2={v*v}N。','圆周运动',2,f'A 2 kg mass travels at {v} m/s in a circle of radius 2 m. Find the required centripetal force.',f'F=mv²/r={v*v} N.',' N')
    num('physics',f'两点电荷相距r时库仑力为{16*k}N，电量不变、距离变为2r，力大小为多少？',4*k,f'F∝1/r²，距离加倍，力变为原来的1/4，即{4*k}N。','库仑定律',2,f'Two point charges exert {16*k} N at distance r. With charges unchanged, find the force at distance 2r.',f'F∝1/r², so the new force is {4*k} N.',' N')
    num('physics',f'质量{m}kg的物块从静止在粗糙水平面运动，恒力{5*m}N与位移同向，摩擦力{m}N，移动2m后的动能是多少？',8*m,f'合力做功W=({5*m}−{m})×2={8*m}J，初动能0，故末动能为{8*m}J。','动能定理综合',3,f'A {m} kg block starts from rest on a rough horizontal surface. A constant forward force {5*m} N acts against friction {m} N. Find its kinetic energy after 2 m.',f'Net work = ({5*m}−{m})×2={8*m} J; by the work–energy theorem this is its final kinetic energy.',' J')
# Chemistry: formula-based variants with units and chemical conditions stated.
for k in range(1,11):
    num('chemistry',f'将{fmt(k/10)}mol NaCl配成体积恰为0.5L的溶液，物质的量浓度为多少？',k/5,f'c=n/V={fmt(k/10)}/0.5={fmt(k/5)}mol/L。注意分母是溶液体积。','物质的量浓度',1,f'{fmt(k/10)} mol NaCl is made into exactly 0.5 L of solution. Find its molarity.',f'c=n/V={fmt(k/5)} mol/L; use solution volume.',' mol/L')
    num('chemistry',f'CO₂的摩尔质量为44g/mol，{k}mol CO₂的质量是多少？',44*k,f'm=nM={k}×44={44*k}g。','摩尔质量',1,f'CO₂ has molar mass 44 g/mol. Find the mass of {k} mol.',f'm=nM={44*k} g.',' g')
    num('chemistry',f'在0℃、101kPa下，理想气体近似取Vₘ=22.4L/mol，{k}mol气体体积约为多少？',22.4*k,f'V=nVₘ={k}×22.4={fmt(22.4*k)}L。','气体摩尔体积',1,f'At 0°C and 101 kPa, take ideal molar gas volume as 22.4 L/mol. Find the approximate volume of {k} mol.',f'V=nV_m={fmt(22.4*k)} L.',' L')
    num('chemistry',f'取浓度{fmt(k/10)}mol/L的溶液100mL，稀释至最终体积500mL，浓度为多少？',k/50,f'c₁V₁=c₂V₂，c₂={fmt(k/10)}×100/500={fmt(k/50)}mol/L。','稀释',2,f'Dilute 100 mL of a {fmt(k/10)} mol/L solution to a final volume of 500 mL. Find the final concentration.',f'c₂=c₁V₁/V₂={fmt(k/50)} mol/L.',' mol/L')
    p=k%5+1
    num('chemistry',f'25℃时，编号{k}的强酸溶液[H⁺]=10⁻{p}mol/L，忽略水电离，pH为多少？',p,f'pH=−lg[H⁺]={p}。','酸碱与pH',1,f'At 25°C, sample {k} is a strong acid with [H⁺]=10^−{p} mol/L. Neglect water ionization. Find pH.',f'pH=−log₁₀[H⁺]={p}.')
    num('chemistry',f'{k}mol Fe²⁺全部氧化为Fe³⁺，转移电子的物质的量是多少？',k,f'Fe²⁺−e⁻=Fe³⁺，每摩尔Fe²⁺失去1mol电子，共{k}mol。','氧化还原电子守恒',2,f'{k} mol Fe²⁺ is fully oxidized to Fe³⁺. Find the moles of electrons transferred.',f'Fe²⁺ → Fe³⁺ + e⁻; each mole transfers 1 mol electrons, giving {k} mol.',' mol')
    num('chemistry',f'2H₂+O₂→2H₂O，{2*k}mol H₂与足量O₂完全反应，生成水的物质的量是多少？',2*k,f'H₂与H₂O的系数相同，n(H₂O)=n(H₂)={2*k}mol。','化学计量',2,f'In 2H₂+O₂→2H₂O, {2*k} mol H₂ reacts completely with excess O₂. How many moles of water form?',f'The mole ratio H₂:H₂O is 1:1, so {2*k} mol forms.',' mol')
    num('chemistry',f'某反应理论产物质量{10*k}g，实际纯产物质量{8*k}g，产率是多少？',80,f'产率=实际/理论×100%={8*k}/{10*k}×100%=80%。','产率',2,f'A reaction has theoretical yield {10*k} g and actual pure yield {8*k} g. Find percent yield.','Percent yield = actual/theoretical ×100%=80%.','%')
    z=k+5;mass=2*z+1
    num('chemistry',f'原子序数{z}、质量数{mass}的原子，其中中子数为多少？',mass-z,f'N=A−Z={mass}−{z}={mass-z}。','原子结构',1,f'An atom has atomic number {z} and mass number {mass}. How many neutrons does it have?',f'N=A−Z={mass-z}.')
    num('chemistry',f'把{k}g溶质溶于{9*k}g水中，完全溶解且无损失，溶质质量分数是多少？',10,f'w=m溶质/m溶液={k}/({k}+{9*k})=10%。','溶液质量分数',1,f'{k} g solute dissolves completely in {9*k} g water without loss. Find solute mass percent.','Mass percent = solute mass / total solution mass ×100% = 10%.','%')
    num('chemistry',f'{k}mol CO₂所含氧原子的物质的量是多少？',2*k,f'每个CO₂含2个氧原子，因此氧原子的物质的量为{2*k}mol。','物质组成',1,f'How many moles of oxygen atoms are contained in {k} mol CO₂?',f'Each CO₂ molecule has 2 oxygen atoms, giving {2*k} mol of atoms.',' mol')
    num('chemistry',f'平衡反应H₂(g)+I₂(g)⇌2HI(g)，某时刻三者浓度依次为1、1、{k}mol/L，浓度商Q是多少？',k*k,f'Q=[HI]²/([H₂][I₂])={k}²/(1×1)={k*k}。','平衡浓度商',3,f'For H₂(g)+I₂(g)⇌2HI(g), concentrations are 1, 1, and {k} mol/L respectively. Find Q_c.',f'Q_c=[HI]²/([H₂][I₂])={k*k}.')
    num('chemistry',f'假设CaCl₂完全电离，{k}mol CaCl₂能产生多少mol Cl⁻？',2*k,f'CaCl₂→Ca²⁺+2Cl⁻，n(Cl⁻)=2×{k}={2*k}mol。','电离与离子',1,f'Assume complete dissociation. How many moles of Cl⁻ are produced by {k} mol CaCl₂?',f'CaCl₂ → Ca²⁺ + 2Cl⁻; this gives {2*k} mol Cl⁻.',' mol')
    num('chemistry',f'按热化学方程式，每消耗1mol燃料释放100kJ热量，消耗{k}mol时反应焓变为多少？',-100*k,f'放热ΔH<0，按计量线性相加，ΔH=−100×{k}={-100*k}kJ。','反应焓',2,f'A thermochemical reaction releases 100 kJ per mole of fuel. Find the enthalpy change when {k} mol reacts.',f'Exothermic ΔH is negative: ΔH={-100*k} kJ.',' kJ')
    num('chemistry',f'用0.1mol/L NaOH恰好中和{10*k}mL、0.2mol/L HCl，需要NaOH溶液多少mL？',20*k,f'一元强酸碱1:1中和，V碱=c酸V酸/c碱=0.2×{10*k}/0.1={20*k}mL。','中和滴定',3,f'How many mL of 0.1 mol/L NaOH exactly neutralize {10*k} mL of 0.2 mol/L HCl?',f'The reaction is 1:1; V_base=0.2×{10*k}/0.1={20*k} mL.',' mL')
    num('chemistry',f'反应2H₂+O₂→2H₂O中，起始{k}mol O₂、{k}mol H₂，完全反应后剩余O₂为多少？',k/2,f'H₂为限量试剂，耗O₂={k}/2mol，剩余{k}−{k}/2={fmt(k/2)}mol。','限量试剂',3,f'For 2H₂+O₂→2H₂O, initially both O₂ and H₂ are {k} mol. Find leftover O₂ after complete reaction.',f'H₂ is limiting; it consumes {fmt(k/2)} mol O₂, leaving {fmt(k/2)} mol.',' mol')
# Biology: quantitative reasoning in specified models; no unsupported clinical claims.
for k in range(1,11):
    total=100*(k+1);a=10*(k+1);g=total//2-a
    num('biology',f'某双链DNA共{total}个碱基，A有{a}个，G有多少个？',g,f'双链A=T、G=C，G=总数/2−A={total}/2−{a}={g}。','DNA碱基互补',2,f'A double-stranded DNA molecule contains {total} bases, including {a} adenines. How many guanines are present?',f'A=T and G=C; G={total}/2−{a}={g}.')
    num('biology',f'一个双链DNA连续复制{k}轮且均成功，最终有多少个双链DNA分子？',2**k,f'每轮分子数加倍，最终2^{k}={2**k}个。','DNA复制',2,f'One double-stranded DNA molecule replicates successfully for {k} rounds. How many double-stranded molecules result?',f'The count doubles each round: 2^{k}={2**k}.')
    num('biology',f'某二倍体体细胞2n={2*(k+1)}，有丝分裂中期有多少条染色单体？',4*(k+1),f'中期每条染色体含2条姐妹染色单体，共2×{2*(k+1)}={4*(k+1)}条。','有丝分裂',2,f'A diploid somatic cell has 2n={2*(k+1)}. How many chromatids are present at metaphase of mitosis?',f'Each chromosome has two sister chromatids: {4*(k+1)} chromatids.')
    num('biology',f'{k}个初级精母细胞正常完成减数分裂，理论上形成多少个精细胞？',4*k,f'一个初级精母细胞形成4个精细胞，共4×{k}={4*k}个。','减数分裂',1,f'{k} primary spermatocytes complete normal meiosis. How many spermatids result?',f'Each produces four spermatids: {4*k} total.')
    num('biology',f'某简化食物链营养级传递效率均取20%，生产者同化能量为{1000*k}kJ，第三营养级最多得到多少能量？',40*k,f'传递两次：{1000*k}×0.2×0.2={40*k}kJ。','生态能量流动',3,f'In a simplified food chain, each trophic transfer is 20% efficient. Producers assimilate {1000*k} kJ. How much reaches the third trophic level?',f'Two transfers: {1000*k}×0.2²={40*k} kJ.',' kJ')
    num('biology',f'完全显性且无致死的Aa×Aa杂交，理论上{4*k}个后代中隐性纯合子的期望数是多少？',k,f'aa概率1/4，期望数={4*k}×1/4={k}。实际小样本不保证恰好此数。','孟德尔遗传',2,f'In an Aa×Aa cross with complete dominance and no lethality, what is the expected number of recessive homozygotes among {4*k} offspring?',f'P(aa)=1/4, so the expectation is {k}; actual small samples may differ.')
    num('biology',f'目镜10×、物镜{k*4}×的显微镜，总放大倍数是多少？',40*k,f'总放大倍数=目镜倍数×物镜倍数=10×{4*k}={40*k}。','生物实验显微观察',1,f'A microscope uses a 10× eyepiece and a {4*k}× objective. Find total magnification.',f'Multiply eyepiece and objective: {40*k}×.','×')
    num('biology',f'同一条件下某叶片总光合速率为{3*k}、呼吸速率为{k}，均以mg CO₂/(dm²·h)计，净光合速率是多少？',2*k,f'净光合=总光合−呼吸={3*k}−{k}={2*k}。','光合作用与呼吸',2,f'Under the same conditions a leaf has gross photosynthesis {3*k} and respiration {k}, both in mg CO₂/(dm²·h). Find net photosynthesis.',f'Net = gross − respiration = {2*k}.',' mg CO₂/(dm²·h)')
    num('biology',f'理想条件下种群每代数量翻倍，初始{k*5}个个体，两代后理论数量是多少？',20*k,f'N₂=N₀λ²={5*k}×2²={20*k}。','种群增长模型',2,f'An ideal population doubles each generation. Starting with {5*k} individuals, what is the predicted size after two generations?',f'N₂=N₀λ²={20*k}.')
    side=k+1
    num('biology',f'把细胞近似为边长{side}μm的立方体，其表面积与体积的比值为多少μm⁻¹？',6/side,f'S/V=6a²/a³=6/a=6/{side}≈{fmt(6/side)}μm⁻¹。','细胞大小与物质交换',3,f'Model a cell as a cube of side {side} μm. Find its surface-area-to-volume ratio (μm⁻¹).',f'S/V=6a²/a³=6/a≈{fmt(6/side)} μm⁻¹.',' μm⁻¹')
    num('biology',f'用标记氮培养的1个双链DNA转入普通氮培养基，复制{k}代，含原标记链的DNA分子有几个？',2,'半保留复制后，两条原链分别保留在2个DNA分子中；从第一代起始终为2个。','半保留复制',3,f'One DNA molecule with both strands nitrogen-labeled is transferred to unlabeled medium and replicates {k} generations. How many molecules contain an original labeled strand?','Semiconservative replication retains the two original strands in two separate DNA molecules, so the answer remains 2 after the first generation.')
    num('biology',f'一条由{k+2}个氨基酸构成的非环状单链多肽，含多少个肽键？',k+1,f'非环状一条肽链，肽键数=氨基酸数−1={k+2}−1={k+1}。','蛋白质结构',1,f'A single noncyclic polypeptide contains {k+2} amino acids. How many peptide bonds does it have?',f'One linear chain has n−1={k+1} peptide bonds.')
# English: 16 families × 10 contexts; meaningful grammatical/reading differences.
contexts=['the school laboratory','the library','the sports hall','the science museum','the classroom','the greenhouse','the observatory','the art room','the computer room','the reading club']
for k,place in enumerate(contexts,1):
    put('english',f'选择恰当形式：By the time we reached {place}, the lesson ___ already begun.','had',['has','is','will'],'过去的“到达”之前已发生，使用过去完成时had begun。','时态',2,f'Choose the correct form: By the time we reached {place}, the lesson ___ already begun.',en_ex='An event completed before another past event uses the past perfect: had begun.')
    put('english',f'填入恰当关系词：This is {place} ___ we carried out the project.','where',['which','what','whose'],'先行词表地点，从句缺地点状语，用where。','定语从句',2,f'Complete: This is {place} ___ we carried out the project.',en_ex='The clause needs a place adverbial, so use where.')
    put('english',f'完成句子：Not until we entered {place} ___ how much work had been done.','did we realize',['we realized','we did realize','had we realized'],'Not until置于句首，主句部分倒装；此处一般过去时用did。','倒装',3,f'Complete: Not until we entered {place} ___ how much work had been done.',en_ex='Fronted Not until triggers subject–auxiliary inversion in the main clause: did we realize.')
    put('english',f'选择恰当形式：The equipment in {place} needs ___ before use.','checking',['check','to checking','checked'],'need doing表示被动含义，相当于need to be done。','非谓语动词',2,f'Choose: The equipment in {place} needs ___ before use.',en_ex='Need + -ing has passive meaning here: needs checking = needs to be checked.')
    put('english',f'完成句子：If we had left {place} earlier, we ___ the last bus.','would have caught',['will catch','would catch','had caught'],'对过去情况的虚拟条件句，主句用would have done。','虚拟语气',3,f'Complete: If we had left {place} earlier, we ___ the last bus.',en_ex='A counterfactual past condition takes would have + past participle in the main clause.')
    put('english',f'填空：All visitors to {place} are required ___ their phones off.','to turn',['turning','turn','turned'],'be required to do为固定结构。','不定式',1,f'Complete: All visitors to {place} are required ___ their phones off.',en_ex='The passive pattern is be required to do something.')
    put('english',f'选择表示“尽管”的连接词：We returned to {place} ___ it was raining heavily.','although',['because of','despite','unless'],'后接完整让步从句，用although；despite与because of不直接接完整从句。','状语从句',2,f'Choose a conjunction meaning “in spite of the fact that”: We returned to {place} ___ it was raining heavily.',en_ex='Although introduces a concessive clause; despite requires a noun phrase or -ing form.')
    put('english',f'填空：The report from {place}, along with two photographs, ___ on the desk now.','is',['are','were','be'],'主语为单数report，along with不改变主谓一致，now用is。','主谓一致',2,f'Complete: The report from {place}, along with two photographs, ___ on the desk now.',en_ex='The singular head noun report controls agreement; along with does not make it plural.')
    put('english',f'完成句子：The teacher suggested that the samples in {place} ___ carefully.','be labeled',['are labeled','were labeling','will label'],'suggest表示建议时，宾语从句用(should) do；此处用被动be labeled。','建议与虚拟语气',3,f'Complete: The teacher suggested that the samples in {place} ___ carefully.',en_ex='After suggest expressing a recommendation, use the mandative base form; the passive is be labeled.')
    put('english',f'填空：___ the instructions, the students began work in {place}.','Having read',['Read','To reading','Having been read'],'read动作先于began，且主语students主动阅读，用Having read。','非谓语时序',3,f'Complete: ___ the instructions, the students began work in {place}.',en_ex='The active reading was completed first, so use the perfect participle Having read.')
    put('english',f'词义辨析：The instructions at {place} were ambiguous. “ambiguous”最接近：','open to more than one interpretation',['impossible to translate','extremely brief','always incorrect'],'ambiguous表示含糊的、可作多种解释的，不等于错误。','高中词汇',2,f'The instructions at {place} were ambiguous. What does ambiguous mean?',en_ex='Ambiguous means open to more than one interpretation, not necessarily wrong.')
    put('english',f'完成句子：It was in {place} ___ the idea first occurred to us.','that',['where','which','what'],'强调句It was...that...，强调地点成分也使用that。','强调句',3,f'Complete: It was in {place} ___ the idea first occurred to us.',en_ex='This is an it-cleft emphasizing the location: It was ... that ... .')
    before=20+k;after=before+10
    put('english',f'阅读：At {place}, attendance rose from {before} to {after} after free entry began. Another nearby venue showed a similar rise without changing its fees. 哪个结论最谨慎？','Free entry alone may not explain the rise.',['Free entry certainly caused the entire rise.','Attendance fell at both venues.','The nearby venue also introduced free entry.'],'比较组未改收费也增长，不能仅凭先后关系断定免费入场是唯一原因。','阅读因果辨析',4,f'At {place}, attendance rose from {before} to {after} after free entry began. A nearby venue showed a similar rise without changing fees. Which conclusion is most cautious?',en_ex='The comparison venue also improved without changing fees; the timing alone does not establish free entry as the sole cause.')
    put('english',f'阅读：A note outside {place} says: “Reservations are optional on weekdays but essential on Saturdays.” Which statement follows?','Saturday visitors must reserve in advance.',['Weekday visitors are never allowed to reserve.','Reservations are unnecessary on Saturdays.','The venue is closed on weekdays.'],'essential表示必需；optional表示可选，不是禁止。','信息提取',2,f'A note outside {place} says: “Reservations are optional on weekdays but essential on Saturdays.” Which statement follows?',en_ex='Essential means required; optional means allowed but not required.')
    put('english',f'阅读：At {place}, a project failed its first trial. Rather than abandon it, the team revised the design and tested again. The team is best described as ___.','persistent',['indifferent','dishonest','careless'],'失败后修改并重试体现坚持，而非漠不关心、欺骗或粗心。','语境词义',2,f'At {place}, a project failed its first trial. The team revised the design and tested again instead of abandoning it. The team is best described as ___.',en_ex='Continuing after a setback demonstrates persistence.')
    put('english',f'阅读：The manager of {place} writes, “Our survey involved only {k+10} volunteers, so its findings should not be generalized to every student.” 这句话主要在做什么？','Acknowledging a limitation of the evidence.',['Claiming every student agrees.','Proving the survey is fraudulent.','Inviting more commercial advertising.'],'作者指出自愿者样本较小，限制结果推广范围，并非否定全部证据。','阅读写作意图',4,f'The manager of {place} writes: “Our survey involved only {k+10} volunteers, so its findings should not be generalized to every student.” What is the main purpose?',en_ex='The author acknowledges the limitations of a small volunteer sample instead of claiming universal applicability.')
# Original campus reading (Chinese class only), with full English alternative text.
for k in range(1,21):
    n=5+k
    put('chinese',f'广播：“第{k}小组请在{n}分钟后于走廊集合。还在考试的同学交卷后再来。”正在考试的玩家应怎样做？','先完成交卷，再按通知集合',['立即中断考试离开','把广播当作正式放学','不看通知直接玩手机'],'阅读限定条件：“还在考试的同学”应在交卷后集合。','条件阅读',2,f'Announcement: “Group {k}, meet in the corridor in {n} minutes. Students taking an exam should come after submitting it.” What should a student currently in an exam do?',en_correct='Submit the exam, then join the group.',en_wrong=['Leave the exam immediately.','Treat it as the final school bell.','Ignore it and use a phone.'],en_ex='The condition explicitly postpones the meeting until after the exam is submitted.')
# Grid pool: answers always integral and within 1..56. All topics high-school.
GRID=[]
def grid(t,n,e,topic,grade,te,ee):
    if not isinstance(n,int) or not 1<=n<=56:raise ValueError(n)
    GRID.append(dict(q=t,n=n,e=e,topic=topic,id38=f'grid-v39-{len(GRID)+1:03}',grade38=grade,normalSeconds38=GR[grade],grading38='高中知识链计算；学科学习模式另补6秒寻找56个编号。',en39=dict(text=te,explain=ee)))
for k in range(1,11):
    grid(f'等差数列a₁={k}，d=2。找到编号a₄。',k+6,f'a₄=a₁+3d={k}+6={k+6}。','等差数列',2,f'a₁={k}, d=2 for an arithmetic sequence. Select a₄.',f'a₄=a₁+3d={k+6}.')
    grid(f'向量a=({k},1)、b=(2,3)。找到编号a·b。',2*k+3,f'a·b=2×{k}+3={2*k+3}。','平面向量',2,f'For a=({k},1) and b=(2,3), select a·b.',f'a·b={2*k+3}.')
    grid(f'函数f(x)=x²+{k}x。找到编号f′(2)。',k+4,f'f′(x)=2x+{k}，f′(2)={k+4}。','导数',2,f'f(x)=x²+{k}x. Select f′(2).',f'f′(x)=2x+{k}; f′(2)={k+4}.')
    grid(f'某等差数列a₂={k+2}、a₅={k+11}。找到编号a₆。',k+14,f'3d=9，d=3，a₆=a₅+3={k+14}。','数列综合',3,f'An arithmetic sequence has a₂={k+2}, a₅={k+11}. Select a₆.',f'3d=9; d=3. Hence a₆={k+14}.')
counts={s:len(a) for s,a in BANK.items()}
(Path(__file__).resolve().parent/'questions39.json').write_text(json.dumps(BANK,ensure_ascii=False,indent=2),encoding="utf-8")
(Path(__file__).resolve().parent/'grid39.json').write_text(json.dumps(GRID,ensure_ascii=False,indent=2),encoding="utf-8")
(Path(__file__).resolve().parent/'bank39_summary.json').write_text(json.dumps(dict(addedChoices=counts,addedTotal=sum(counts.values())+len(GRID),addedGrid=len(GRID),total=196+sum(counts.values())+len(GRID)),indent=2),encoding="utf-8")
print(counts, 'added grids',len(GRID),'total',196+sum(counts.values())+len(GRID))
