"""Focused v3.7 browser tests. Test hooks supply deterministic states, not human timing.
Run: python tests/test_update37.py. Requires Python playwright + Chromium.
"""
import json,re,time
from pathlib import Path
from support import *

def main():
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=CHROMIUM_BIN,args=['--no-sandbox'])
  ctx=browser.new_context(viewport={'width':1600,'height':1000},has_touch=True)
  h=Harness(ctx,False)
  def ready(d='normal',real=False,subject=3):
   h.fresh();h.ev(f'T.save.settings.studyMode=true;T.save.settings.realMode={str(real).lower()};T.start("quick",{json.dumps(d)});T.finishDialogue();const i=T.timetable.findIndex(x=>x.lesson==={subject});T.enterCampus(i<0?1:i);T.finishDialogue();T.testClear37();T.state.v34.book.corrections=0;T.state.dangerCooldown=0;T.render();')
  def eq(code,want=True):
   got=h.ev(code);ensure(got==want,f'{got!r} != {want!r}')
  def js(name,code,want=True):h.run(name,lambda:eq(code,want))
  h.fresh()
  js('Boot / 48 unique endings + 174 unique achievements','return [Object.keys(T.endings).length,T.achievements.length,new Set(T.achievements.map(x=>x.id)).size];',[48,174,174])
  js('New settings default off','return !T.save.settings.realMode&&!T.save.settings.dialogueVoice;')
  for diff,owned in [('easy',True),('normal',True),('hard',False),('hell',False),('extreme',False),('god',False)]:
   h.run('Mirror default '+diff,lambda d=diff,o=owned:(ready(d),eq('return T.state.v37.mirror.owned;',o)))
  h.run('Physics mirror quest blocked in classroom',lambda:(ready('hard'),eq('return T.startMirrorQuestion37();',False)))
  def quest_setup():
   h.fresh();h.ev('T.start("quick","hard");T.finishDialogue();')
  def quest_right():
   quest_setup();eq('T.startMirrorQuestion37();const c=T.challenge;T.number(c.correct);return T.state.v37.mirror.owned&&T.state.v37.mirror.source==="earned"&&!!T.save.achievements.mirrorGet37;');ensure(h.valid() is True,h.valid())
  h.run('Mirror quest: high-school answer awards actual inventory',quest_right)
  def wrong_quest():
   quest_setup();eq('T.startMirrorQuestion37();T.number((T.challenge.correct+1)%4);return !T.state.v37.mirror.owned&&T.state.v37.mirror.cooldown===T.state.t+20&&!T.startMirrorQuestion37();')
  h.run('Wrong answer: no mirror and 20s retry cooldown',wrong_quest)
  h.run('Sleeping representative cannot give mirror',lambda:(quest_setup(),eq('T.state.v34.allies.wang.mode="sleep";return T.startMirrorQuestion37();',False)))
  def quest_pause():
   quest_setup();h.ev('T.startMirrorQuestion37();T.tick(1);');before=h.ev('return T.challenge.remaining;');h.ev('T.openModal("pause");T.tick(9);');eq('return T.challenge.remaining;',before);h.ev('T.resume();');ensure(h.valid() is True,h.valid())
  h.run('Mirror challenge pauses, serializes and does not damage grades',quest_pause)
  def turning():
   ready('hard');eq('T.state.campus.rear.nextAllowed=0;T.door(true,12);T.render();T.spotRear();return T.state.campus.rear.spotted===0&&getComputedStyle(document.getElementById("doorShadow")).opacity==="0";')
   eq('T.turnBack37();T.advanceTurn37(1);return T.state.v37.turn.phase==="turning"&&T.state.campus.rear.spotted===0;')
   eq('T.advanceTurn37(.16);T.render();return T.state.v37.turn.phase==="view"&&T.state.campus.rear.spotted===1&&T.state.v37.turnSeen.length===1;')
   eq('T.spotRear();T.advanceTurn37(4);T.render();return T.state.v37.turnSeen.length===1&&T.state.v37.turn===null&&T.state.action==="listen";')
  h.run('No mirror: 1.15s turn, one observation, 4s view, then return',turning)
  def mirror_seen():
   ready();eq('T.state.campus.rear.nextAllowed=0;T.door(true,12);T.spotRear();return T.state.v37.mirrorSeen.length===1&&T.state.v37.turnSeen.length===0;')
  h.run('Owned mirror identifies real rear visits',mirror_seen)
  def turn_save():
   ready('hard');h.ev('T.turnBack37();T.advanceTurn37(.5);');ensure(h.valid() is True,h.valid());h.roundtrip();eq('return Math.abs(T.state.v37.turn.remaining-.65)<.001;')
  h.run('Turn-back progress survives new-document resume',turn_save)
  h.run('New question bank counts / exclusive high-school topics',lambda:(ready(),eq('return Object.fromEntries(Object.entries(T.questions37).map(([k,v])=>[k,v.length]));',{'chinese':25,'chemistry':190,'biology':150,'physics':190,'english':190,'math':216})))
  js('Every question has four distinct answers and an explanation','return Object.values(T.questions37).flat().every(q=>new Set(q.choices).size===4&&q.answer>=0&&q.answer<4&&q.explain.length>5&&q.topic37&&q.id37);')
  js('Grid bank: 75 high-school problems and answers in 1–56','return T.gridBank37.length===75&&T.gridBank37.every(q=>Number.isInteger(q.n)&&q.n>=1&&q.n<=56&&q.q&&q.e&&q.topic);')
  for subject in ['chemistry','biology','physics','english','math']:
   js('Persistent no-repeat question deck '+subject,f'const n=T.questions37.{subject}.length,a=Array.from({{length:n}},()=>T.deckDraw37("{subject}"));return new Set(a).size===n;')
  def question_answer():
   ready();eq('T.question("physics");const id=T.challenge.qid37;T.number(T.challenge.correct);return T.state.v37.correct.includes(id)&&T.state.v37.subjects.includes("physics");')
  h.run('New answer records subject achievement progress',question_answer)
  def gridlight():
   ready(subject=5);eq('T.state.v37.math={listened:0,active:30};T.grid();T.render();return T.challenge.glow37===0&&[...document.querySelectorAll("[data-number]")].every(b=>!b.style.boxShadow);')
   eq('T.closeChallenge();T.state.v37.math={listened:15,active:30};T.grid();return T.challenge.glow37===.25;')
   eq('T.closeChallenge();T.state.v37.math={listened:30,active:30};T.grid();T.number(T.challenge.correct);return !!T.save.achievements.gridMemory37;')
  h.run('Grid glow is continuous 0 / .25 / 1 and records earned clue',gridlight)
  h.run('Ordinary questions never glow',lambda:(ready(subject=5),eq('T.state.v37.math={listened:30,active:30};T.question("math");return T.challenge.glow37===undefined&&!document.querySelector(".memory-flash");')))
  def listening():
   ready(subject=5);eq('T.state.nextDoor=999;T.state.nextRandom=999;T.state.teacher.hold=999;T.updateClass(1);return T.state.v37.math.listened===1&&T.state.v37.math.active===1;')
   eq('T.state.action="cube";T.updateClass(1);return T.state.v37.math.listened===1&&T.state.v37.math.active===2;')
   eq('T.openModal("pause");T.tick(9);return T.state.v37.math.active===2;')
  h.run('Only actual math listening raises the cue, not pauses or play',listening)
  def realphone():
   ready(real=True);eq('T.setAction("phone");T.danger();T.failHide();return T.challenge.type==="surrender37"&&T.challenge.item37==="phone"&&T.state.suspicion===100;')
   ensure(h.valid() is True,h.valid());eq('T.choose(0);T.setAction("phone");T.render();return T.state.v37.lost.includes("phone")&&!T.phoneAllowed()&&T.state.action==="listen"&&document.querySelector("[data-action=phone]").hidden;');ensure(h.valid() is True,h.valid())
  h.run('Real quick failure: exactly 100%, surrender and remove phone',realphone)
  def three_items():
   ready(real=True)
   for item in ['phone','cube','chess']:
    h.ev(f'T.state.suspicion=0;T.state.dangerCooldown=0;T.setAction("{item}");T.danger();T.failHide();T.choose(0);')
   eq('return T.state.endingId;','realEmpty37')
  h.run('Three distinct confiscations unlock the new bad ending',three_items)
  def noitem():
   ready(real=True);eq('T.danger();T.failHide();T.choose(0);return T.state.v37.lost.length===0&&T.state.v37.realCaught===1&&T.state.action==="listen";')
  h.run('No held item: discipline only, essential actions retained',noitem)
  def normalpunish(subject,number):
   ready(real=False,subject=subject);eq('T.danger();T.failHide();return T.state.suspicion;',number)
  h.run('Non-real ordinary quick failure retains +36',lambda:normalpunish(3,36))
  h.run('Non-real math quick failure retains +48',lambda:normalpunish(5,48))
  h.run('Tutorial quick failure does not confiscate',lambda:(ready(real=True),eq('T.setAction("phone");T.danger("练习",true);T.failHide();return !T.challenge&&!T.state.v37.lost.length&&T.state.dangerFails===0;')))
  def real_restore():
   ready(real=True);h.ev('window.__early=T.captureSnapshot("earlier");T.setAction("cube");T.danger();T.failHide();T.choose(0);T.restore(window.__early);T.resume();');eq('return T.state.v37.lost.includes("cube")&&T.state.v37.realCaught===1&&!T.hasItem37("cube");')
   h.roundtrip();eq('return T.state.v37.lost.includes("cube")&&!T.hasItem37("cube");');ensure(h.valid() is True,h.valid())
  h.run('Confiscation ledger survives earlier checkpoint and full page reconstruction',real_restore)
  def real_locks():
   ready(real=True);eq('T.save.settings.studyMode=true;T.save.settings.realMode=false;T.setAction("cube");T.danger();T.failHide();return T.challenge.type==="surrender37";')
  h.run('Realism fixed at start, settings cannot evade current punishment',real_locks)
  def evidence(kind):
   ready();h.ev(f'T.state.campus.rear.nextAllowed=0;T.door(true,12);T.state.door.inspector="郭梓晁";T.state.door.camera37="{kind}";T.rearViolation("chess");')
   eq('return T.state.campus.office.pending&&T.state.v37.evidence.length===1&&T.state.v37.evidence[0].viewed===false;')
   h.ev('T.enterOffice();T.finishDialogue();');eq('return T.challenge.type;','officeQuestion');h.ev('T.choose(0);T.finishDialogue();');eq('return T.challenge.type;','evidence37');ensure(h.valid() is True,h.valid())
   if kind=='video':
    h.ev('T.choose(0);');eq('return T.challenge.type;','evidence37');h.ev('T.tick(1.5);');h.roundtrip();h.ev('T.resume();');eq('return T.challenge.elapsed;',1.5);h.ev('T.tick(1.6);')
   h.ev('T.choose(0);');eq('return T.state.v37.evidence[0].viewed;');ensure(h.valid() is True,h.valid())
  h.run('Photo evidence, reprimand first, then confirm frame',lambda:evidence('photo'))
  h.run('Video evidence, 3s gate, save/resume and return to schedule',lambda:evidence('video'))
  def rear_prevent():
   ready();eq('T.state.t=10;T.state.campus.rear.nextAllowed=0;T.door(true,12);T.state.door.born=8;T.state.door.inspector="郭梓晁";T.state.door.camera37="photo";T.setAction("phone");T.updateDoor(.1);T.safeHide();T.updateDoor(.5);return T.state.v37.evidence.length===0&&T.state.door.cameraWarn37;')
  h.run('Camera warning can be avoided before confirmation',rear_prevent)
  h.run('Higher rear probability normal / phone / math',lambda:(ready(),eq('const a=T.rearProbability();T.state.action="phone";const b=T.rearProbability();T.state.classIndex=5;return [a,b,T.rearProbability()];',[.12,.22,.32])))
  def principal(who):
   ready(subject=0 if who=='cheng' else 6);eq(f'return T.principalVisit37("{who}");');h.ev('T.finishDialogue();')
   if who=='cheng':eq('return T.state.v37.stats.cheng37===1;')
   else:
    eq('return T.state.v37.principal.xuCleaning&&T.state.v34.clean.phase==="request";')
    h.ev('T.state.v34.clean.done=[0,1];T.state.v34.task={type:"clean",elapsed:2.2,duration:2.2,key:"2",roll:0};') if False else None
   ensure(h.valid() is True,h.valid())
  h.run('Cheng slow school address and completion achievement',lambda:principal('cheng'))
  h.run('Xu meddling becomes real hygiene request',lambda:principal('xu'))
  def slowvoice():
   ready();eq('return T.voicePlan37("程今容","同学们……呼……等一下。" ).parts.length===3&&T.voicePlan37("程今容","好").rate<.6&&T.voicePlan37("郭梓晁","好").rate===1;')
   eq('return T.speak37("郭梓晁","你好")===false&&T.speechBusy37===false;')
  h.run('Speech is opt-in and principal uses slower rate + breathing pauses',slowvoice)
  def speech_fallback():
   ready();eq('T.save.settings.dialogueVoice=true;return typeof T.speak37("尹沙沙","省水省电省实验。") ==="boolean";');eq('T.stopSpeech37();return T.speechBusy37===false;')
  h.run('Unsupported/no-local-voice fallback is nonblocking',speech_fallback)
  h.run('Eighteen tutorial chapters include all new systems',lambda:(ready(),eq('T.openTutorial36();T.selectTutorial36("props37");return T.tutorialLessons36.length===18&&document.getElementById("learnContent36").innerText.includes("1.15");')))
  def tutorial_isolation():
   ready(real=True);h.ev('T.setAction("phone");T.danger();window.__before=JSON.stringify(T.state);T.openTutorial36();T.tick(10);');eq('return JSON.stringify(T.state)===window.__before;');h.ev('T.closeTutorial36();');eq('return T.challenge.type;','hide')
  h.run('Tutorial freezes live real-mode danger without mutating state',tutorial_isolation)
  def examisolation():
   ready();h.ev('T.beginTest35();T.render();');eq('return T.isExam35()&&document.getElementById("propDock37").hidden&&document.getElementById("actionDock").hidden&&!T.startMirrorQuestion37();')
  h.run('Formal exams still hide ALL regular and prop actions',examisolation)
  def snapshot_settings():
   ready(real=True);h.ev('T.openModal("settings");');eq('return document.querySelector("[data-setting=realMode]").checked&&!document.querySelector("[data-setting=dialogueVoice]").checked;');h.page.screenshot(path=str(ROOT/'tests/settings37.png'))
  h.run('Settings contains real mode and voice toggles',snapshot_settings)
  def newroutes():
   ready();eq('T.state.phase="COMPLETE";T.showPack();T.render();return !!document.querySelector("[data-prop37=routes]");');h.ev('T.showRoutes37();');eq('return T.challenge.routeIds37.length===3&&T.challenge.locks.filter(Boolean).length===3;');ensure(h.valid() is True,h.valid())
  h.run('New endings exposed via actual final selection with unmet locks',newroutes)
  def endings(id):
   ready('hard',True);h.ev('T.state.phase="COMPLETE";T.state.v37.mirror.source="earned";T.state.v37.mirror.owned=true;T.state.v37.mirrorSeen=["a","b","c"];T.state.v37.turnSeen=["a","b","c"];T.state.runStats.hides=3;')
   if id=='lookBack37':h.ev('T.state.v37.mirror.source="none";T.state.v37.mirror.owned=false;')
   if id=='realLight37':h.ev('T.state.v37.lost=["cube"];')
   if id=='evidenceExit37':h.ev('T.state.v37.evidence=[{viewed:true,kind:"photo"},{viewed:true,kind:"video"}];T.state.campus.office.resolved=1;')
   h.ev(f'T.ending("{id}");');eq('return T.state.endingId;',id)
  for id in ['mirrorPath37','lookBack37','realClean37','realLight37','evidenceExit37']:
   h.run('Ending predicate and dispatch '+id,lambda id=id:endings(id))
  h.run('God still seals added success ending',lambda:(ready('god',True),eq('T.state.phase="COMPLETE";T.state.v37.lost=["cube"];T.ending("realLight37");return T.state.endingId!=="realLight37";')))
  def layout():
   ready('hard');h.page.set_viewport_size({'width':390,'height':844});h.ev('T.settingChange({dataset:{setting:"mobileMode"},checked:true});T.render();');h.page.wait_for_timeout(100)
   bb=h.page.locator('#rearButton37').bounding_box();ensure(bb and bb['width']>=44 and bb['height']>=43,bb);h.page.screenshot(path=str(ROOT/'tests/mobile37.png'));h.page.set_viewport_size({'width':1600,'height':1000})
  h.run('Phone portrait: prop button touch size and view',layout)
  def actual_input():
   ready('hard');h.page.locator('#rearButton37').tap();eq('return T.state.v37.turn.phase;','turning');h.page.keyboard.press('Escape');h.ev('T.tick(3);');eq('return T.state.v37.turn.remaining;',1.15);h.ev('T.resume();')
  h.run('Real DOM touch turn-back and Escape pause',actual_input)
  def full():
   ready();h.page.keyboard.press('Alt+Enter');h.page.wait_for_timeout(150);ensure(h.page.evaluate('!!document.fullscreenElement'));h.page.keyboard.press('Alt+Enter')
  h.run('Actual Fullscreen API enter and exit',full)
  def validationbad():
   ready();eq('const s=T.captureSnapshot();s.state.v37.lost=["not_an_item"];try{T.validateSnapshot(s);return false;}catch{return true;}')
  h.run('Malformed inventory rejected',validationbad)
  ensure(not ERRORS,'Runtime errors: '+repr(ERRORS))
  ctx.close();browser.close()
 ROOT.joinpath('tests/regression39_results.json').write_text(json.dumps({'results':RESULTS,'pageErrors':ERRORS},ensure_ascii=False,indent=2))
 print('RESULT',sum(x['passed'] for x in RESULTS),'/',len(RESULTS))
 if any(not x['passed'] for x in RESULTS):raise SystemExit(1)
if __name__=='__main__':main()
