from support import *
DRIVER=(ROOT/'tests/school_driver39.js').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CHROMIUM_BIN,args=['--no-sandbox']);ctx=b.new_context();h=Harness(ctx,False)
 def flow(d='normal',study=False,campaign='day',mode='quick',read=.15,escape=False):
  h.fresh();h.ev(f'T.save.settings.studyMode={str(study).lower()};T.start("{mode}","{d}","{campaign}",39303);')
  if escape:h.ev('T.finishDialogue();T.enterCampus(T.timetable.findIndex(x=>x.lesson===5));T.finishDialogue();T.escape();')
  r=h.ev(f'const READ_FRACTION={read};'+DRIVER)
  metrics=h.ev('return {questions:T.state.questionRight,gridLessons:T.state.v39.gridLessons,weekResults:T.state.calendar.results.length,sports:T.state.v39.sports,study:T.state.v39.study};')
  label=f'{d}_{study}_{campaign}_{mode}_{escape}'
  (ROOT/f'tests/flow39_{label}.json').write_text(json.dumps({'flow':r,'metrics':metrics},ensure_ascii=False,indent=2))
  ensure(r['ending'] and r['ending'] not in ['loop','phone','mind','mirror','godLoop'],str(r))
  ensure(h.valid() is True,str(h.valid()))
  if campaign=='week':ensure(len(r['results'])==7 and len(r['homeWindows'])==7,str(r))
  if escape:ensure(r['ending']=='true' and 'grid' in r['seen'] and h.ev('return T.state.v39.gridSeries===null;'),str(r))
 for d in ['easy','normal','hard','hell','extreme']:h.run('Casual full quick day / '+d,lambda d=d:flow(d))
 h.run('Study normal standard day with 60% reading budget',lambda:flow(study=True,mode='normal',read=.6))
 h.run('Casual complete seven days and seven bedrooms',lambda:flow(campaign='week'))
 h.run('Study complete seven days and seven bedrooms',lambda:flow(study=True,campaign='week',read=.25))
 for study in [False,True]:h.run(('Study five-grid' if study else 'Casual three-grid')+' escape with 80% reading',lambda study=study:flow(study=study,escape=True,read=.8))
 h.run('No unhandled full-flow errors',lambda:ensure(not ERRORS,str(ERRORS)))
 b.close()
 out={'results':RESULTS,'pageErrors':ERRORS,'passed':sum(x['passed'] for x in RESULTS),'total':len(RESULTS)}
 (ROOT/'tests/flow39_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('RESULT',out['passed'],out['total'])
 if out['passed']!=out['total']:raise SystemExit(1)
