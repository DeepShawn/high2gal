    // Phone mode relocates the actual controls, not screenshot copies. Original anchors restore desktop.
    const phoneShell39=document.createElement('section');phoneShell39.id='phoneShell39';phoneShell39.hidden=true;
    phoneShell39.innerHTML=`<header class="phone-header39"><b>THE LAST CLASS <small>v3.9</small></b><nav>${button39('settings','设置','Settings')}${button39('pause','暂停','Pause')}${button39('saves','存档','Save')}${button39('tutorial','教程','Tutorial')}${button39('fullscreen','全屏','Fullscreen')}</nav></header><div id="phoneMenu39"></div><div id="phonePreview39"><div id="phoneArt39"><div class="phone-board39"><b id="phoneArtTitle39"></b><small id="phoneArtSub39"></small></div><div class="phone-teacher39"><i></i><span id="phoneArtTeacher39"></span></div><div class="phone-seats39"><i></i><i></i><i></i><i></i></div><div class="phone-rear39"><i></i><span id="phoneArtRear39"></span></div><div class="phone-court39"></div><div class="phone-bed39"></div></div></div><div id="phoneStatus39" aria-live="polite"></div><main id="phonePlay39"></main><div id="phoneSide39"></div><div id="phoneHome39"></div><div id="phoneDialogue39"></div><div id="phoneEnding39"></div><footer id="phoneDock39"><div id="phoneActions39"></div><div id="phoneQuick39">${button39('hide','立即收好／收声','Put away / stop')}${button39('friends','同学','Friends')}</div></footer><div id="phoneOverlay39"></div>`;
    document.body.appendChild(phoneShell39);
    const relocation39=new Map();let phoneApplied39=false;
    function relocate39(node,target){if(!node||relocation39.has(node))return;const anchor=document.createComment('desktop anchor '+(node.id||node.className));node.before(anchor);relocation39.set(node,anchor);target.appendChild(node);}
    function syncMobile39(){const on=!!save.settings.mobileMode;document.documentElement.lang=lang39()==='en'?'en':lang39()==='zh-TW'?'zh-Hant':'zh-Hans';
      if(on!==phoneApplied39){phoneApplied39=on;document.body.classList.toggle('phone-mode39',on);phoneShell39.hidden=!on;
        if(on){for(const [id,target] of [['menu','phoneMenu39'],['gameUI','phonePlay39'],['actionDock','phoneActions39'],['chessPanel','phoneSide39'],['talkPanel','phoneSide39'],['toastStack','phoneOverlay39'],['campusPanel','phoneSide39'],['lifeDock34','phoneSide39'],['lifePanel34','phoneSide39'],['propDock37','phoneSide39'],['nav39','phoneSide39'],['dialogue','phoneDialogue39'],['ending','phoneEnding39'],['challengeLayer','phoneOverlay39'],['modal','phoneOverlay39'],['resumeBanner','phoneOverlay39'],['escapeHud','phoneSide39'],['viewport','phonePreview39']])relocate39($(id),$(target));
          relocate39(document.querySelector('.home-interface'),$('phoneHome39'));
        }else{for(const [node,anchor] of relocation39){if(anchor.isConnected){anchor.replaceWith(node);}}relocation39.clear();$('viewport').removeAttribute('style');$('stage').style.removeProperty('left');$('stage').style.removeProperty('top');$('stage').style.removeProperty('transform-origin');BASE39.resize();}
      }
      if(!on)return;
      phoneShell39.inert=tutorialActive36();$('phoneMenu39').hidden=!(!$('menu').hidden);const playing=S?.screen==='game';$('phonePreview39').hidden=!playing;$('phonePlay39').hidden=!playing||S?.phase==='HOME';$('phoneSide39').hidden=!playing||S?.phase==='HOME';$('phoneHome39').hidden=!playing||S?.phase!=='HOME';$('phoneDialogue39').hidden=!playing||S?.phase==='HOME';$('phoneEnding39').hidden=$('ending').hidden;
      $('phoneStatus39').hidden=!playing;const status=playing?L39((S.phase==='HOME'?'归家':campusName())+' · '+(study39()?'学习':'休闲')+' · '+DIFFICULTIES[S.difficulty].label,(S.phase==='HOME'?'BEDROOM':'CAMPUS')+' · '+(study39()?'STUDY':'CASUAL')+' · '+['EASY','NORMAL','HARD','HELL','EXTREME','GOD'][DIFFICULTIES[S.difficulty].rank]):'';
      if(playing&&$('phoneStatus39').textContent!==status+' · '+L39('疑','Risk')+Math.round(S.suspicion)+' / '+L39('专','Focus')+Math.round(S.focus)+' / '+L39('无聊','Bored')+Math.round(S.boredom))$('phoneStatus39').textContent=status+' · '+L39('疑','Risk')+Math.round(S.suspicion)+' / '+L39('专','Focus')+Math.round(S.focus)+' / '+L39('无聊','Bored')+Math.round(S.boredom);
      $('phoneDock39').hidden=!playing||S.phase==='HOME'||!!challenge||!!script||busy34()||S.discipline.standing;
      renderPhoneArt39();
      const w=Math.min(innerWidth,900),stage=$('stage');stage.style.transform='scale('+(w/1600)+')';stage.style.transformOrigin='top left';stage.style.left='0';stage.style.top='0';$('viewport').style.width=w+'px';$('viewport').style.height=(w*900/1600)+'px';$('viewport').style.position='relative';$('viewport').style.transform='none';
      // Kept as one page, but no reflowing the scene can shrink the interaction controls.
      localize39(phoneShell39.querySelector('.phone-header39'));localize39($('phoneSide39'));localize39($('phoneHome39'));
    }
    function renderPhoneArt39(){if(!S)return;const art=$('phoneArt39'),home=S.phase==='HOME',pe=campusSlot()?.kind==='pe',r=S.home?.parent;
      art.dataset.scene=home?'bedroom':pe?'sports':S.phase==='CLASS'?'classroom':S.campus.location;
      art.classList.toggle('fear39',!!save.settings.fearMode);
      $('phoneArtTitle39').textContent=home?L39('归家 · 门边的脚步','HOME · FOOTSTEPS'):pe?L39('体育 · '+(SPORTS39[S.v39?.pe.choice]?.name||'选项目'),'PE · '+(SPORTS39[S.v39?.pe.choice]?.en||'Choose a track')):L39(CLASSES[S.classIndex]?.subject||'校园',({chinese:'Chinese',chemistry:'Chemistry',biology:'Biology',physics:'Physics',english:'English',math:'Math',study1:'Evening study I',study2:'Evening study II'})[CLASSES[S.classIndex]?.id]||'Campus');
      $('phoneArtSub39').textContent=home?(S.home?.action==='phone'?L39('手机亮着','PHONE ON'):L39('保持安静','KEEP QUIET')):isExam35()?L39('坐在讲台监考','SEATED INVIGILATION'):L39('留意真实危险预警','WATCH THE REAL WARNINGS');
      $('phoneArtTeacher39').textContent=home?'':pe?'刘嗨':CLASSES[S.classIndex]?.teacher||'';
      const known=home||mirrorUsable37()||S.v37?.turn?.phase==='view';const threat=home?!!r&&r.phase!=='passing':known&&!!S.door?.real;
      art.classList.toggle('rear-warning39',threat);$('phoneArtRear39').textContent=home?(r?L39('家长在门边','PARENT NEAR'):L39('门外安静','QUIET')):known?(threat?L39('后门有人','REAR DOOR'):L39('后门','REAR')):L39('先回头确认','TURN TO CHECK');
      const tx=home?0:Math.max(0,Math.min(1,(S.teacher?.x||842)/1600));art.style.setProperty('--teacher-x39',(20+tx*42)+'%');
    }
    resize=function(){BASE39.resize();if(save.settings.mobileMode)syncMobile39();};
    window.addEventListener('resize',()=>{if(save.settings.mobileMode)syncMobile39();});
    $('menuStudy39').addEventListener('change',e=>settingChange(e.target));
