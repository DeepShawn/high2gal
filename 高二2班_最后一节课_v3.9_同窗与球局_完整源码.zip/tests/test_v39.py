from support import *
from pathlib import Path

def approx(x,y): ensure(abs(x-y)<.001,f'{x} != {y}')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CHROMIUM_BIN,args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':1280,'height':800});h=Harness(ctx,False)
 def start(study=False,d='normal'):
  h.fresh();h.ev(f'T.save.settings.studyMode={str(study).lower()};T.start("quick","{d}","day",39001);T.finishDialogue();')
 def free():h.ev('T.testClear37();T.state.phase="CAMPUS";T.state.v34.recess=null;T.state.v34.stand=0;T.state.discipline.standing=false;T.state.campus.location="playground";')
 def cleanlesson(index):h.ev(f'T.testClear37();T.lesson({index});T.finishDialogue();T.testClear37();T.state.phase="CLASS";T.state.v34.book.corrections=0;T.state.nextEvent=99999;T.state.nextDoor=99999;T.state.teacher.hold=T.state.t+9999;')
 h.fresh()
 h.run('Boot defaults: desktop, casual, both romances off',lambda:ensure(h.ev('return !T.save.settings.studyMode&&!T.save.settings.mobileMode&&!T.save.settings.wangRoute&&!T.save.settings.pengRoute;')))
 h.run('1036 academic entries, 75 grids, 48 endings, 174 achievements',lambda:ensure(h.ev('const d=T.debug39();return d.questions===1036&&d.grids===75&&d.endings===48&&d.achievements===174;')))
 h.run('Every question has grade, valid unique ID and correct option',lambda:ensure(h.ev('const q=T.questionCatalog38.filter(x=>x.kind!=="route");return new Set(q.map(x=>x.id)).size===1036&&q.every(x=>x.grade>=1&&x.grade<=4&&(x.kind==="grid"?x.answer>=1&&x.answer<=56:x.choices.length===4&&x.answer>=0&&x.answer<4));')))
 h.run('All 840 added question entries contain English text and explanation',lambda:ensure(h.ev('const a=[...Object.values(T.questions37).flat().filter(x=>x.id37.includes("v39")),...T.gridBank37.filter(x=>x.id38.includes("v39"))];return a.length===840&&a.every(x=>x.en39.text&&x.en39.explain&&(!x.choices||x.en39.choices.length===4));')))
 for study in [False,True]:
  start(study)
  def formula(study=study):
   result=h.ev('const id=T.questions37.math.find(x=>x.grade38===2).id37;return T.difficulties?Object.keys(T.difficulties).map(d=>T.makeQuestionTiming38(id,{...T.state,difficulty:d},"oral").total):[];')
   factors=[1.3,1,.88,.78,.68,.58];base=25 if study else 12
   for a,f in zip(result,factors):approx(a,round(base*f,1))
  h.run(('Study' if study else 'Casual')+' six timing multipliers',formula)
  h.run(('Study' if study else 'Casual')+' new save validates',lambda:ensure(h.valid() is True,str(h.valid())))
 start(False)
 h.run('Next-run study setting cannot mutate current run',lambda:ensure(h.ev('T.settingChange({dataset:{setting:"studyMode"},checked:true});return !T.state.v39.study&&T.save.settings.studyMode;')))
 start(False)
 h.run('Casual draws only L1/L2 across 6 subjects',lambda:ensure(h.ev('for(const s of Object.keys(T.questions37)){for(let n=0;n<200;n++){const i=T.deckDraw37(s);if(T.questions37[s][i].grade38>2)return false;}}return true;')))
 start(True)
 h.run('Study draws L3/L4 as well',lambda:ensure(h.ev('const gs=new Set();for(let n=0;n<230;n++)gs.add(T.questions37.chemistry[T.deckDraw37("chemistry")].grade38);return gs.has(3)||gs.has(4);')))
 for study,expect in [(False,3),(True,5)]:
  start(study);cleanlesson(5)
  h.run(f'Class math scheduling has exactly {expect} number grids',lambda expect=expect:ensure(h.ev('T.state.elapsed=T.state.duration*.99;for(let i=0;i<10;i++)T.scheduledEvents();return T.queue.filter(x=>x.action==="gridQuestion39").length;')==expect))
  h.run('Repeated schedule calls cannot duplicate original events',lambda:ensure(h.ev('const q=T.queue.map(x=>x.key);return new Set(q).size===q.length;')))
 for sport,index in [('badminton',0),('basketball',1),('pingpong',2)]:
  start(False)
  def pe(index=index,sport=sport):
   r=h.ev(f'T.testClear37();const i=T.timetable.findIndex(x=>x.kind==="pe");T.enterCampus(i);T.finishDialogue();const first=T.challenge?.type;T.choose({index});T.choose(2);for(const id of ["run","ball","walk"]){{T.startSport(id);T.updateCampus(6);}}return {{first,choice:T.state.v39.pe.choice,done:T.state.campus.pe.done.length,sport:T.state.v39.sports.at(-1)?.sport}};')
   ensure(r=={'first':'peSelect39','choice':sport,'done':3,'sport':sport},str(r))
  h.run('PE entry selection and three drills: '+sport,pe)
  h.run('Completed PE snapshot validates',lambda:ensure(h.valid() is True,str(h.valid())))
 start(False)
 def bonus():
  r=h.ev('T.save.settings.wangRoute=true;T.testClear37();T.enterCampus(T.timetable.findIndex(x=>x.kind==="pe"));T.finishDialogue();T.choose(0);T.choose(1);for(const id of ["run","ball","walk"]){T.startSport(id);T.updateCampus(6);}const a=T.state.v39.wang.affection;T.updateCampus(1);return {a,b:T.state.v39.wang.affection,bonus:T.state.v39.bonuses};')
  ensure(r=={'a':18,'b':18,'bonus':1},str(r))
 h.run('Badminton + romance bonus applies once after full session',bonus)
 start(False);free()
 h.run('Friendship conversation works with romance off; letter blocked',lambda:ensure(h.ev('const x=T.socialAction39("wang","chat","boundary");T.updateSocial39(4);const y=T.socialAction39("wang","letter");return x&&!y&&T.state.v39.wang.chats===1&&T.state.v39.wang.affection===8;')))
 h.run('Same topic cannot farm affection in same day',lambda:ensure(h.ev('return !T.socialAction39("wang","chat","boundary")&&T.state.v39.wang.affection===8;')))
 h.run('Cancelled conversation grants no reward',lambda:ensure(h.ev('T.socialAction39("wang","chat","rest");T.updateSocial39(1);T.safeHide();return T.state.v39.wang.chats===1&&!T.state.v39.social;')))
 h.run('Enabled letter progresses only after completion',lambda:ensure(h.ev('T.save.settings.wangRoute=true;T.socialAction39("wang","letter");T.updateSocial39(2);if(T.state.v39.wang.letters)return false;T.updateSocial39(3);return T.state.v39.wang.letters===1;')))
 h.run('Exam blocks new character actions',lambda:ensure(h.ev('T.testClear37();T.lesson(3);T.finishDialogue();T.testClear37();T.beginTest35();return !T.socialAction39("wang","chat","sport");')))
 start(False);free()
 def social_restore():
  h.ev('T.socialAction39("wang","chat","boundary");T.updateSocial39(1.25);T.autoSave("social partial");')
  ensure(h.valid() is True,str(h.valid()));d=h.page.evaluate('__disk');h.fresh(d);h.ev('T.continueGame();T.resume();');approx(h.ev('return T.state.v39.social.elapsed;'),1.25)
 h.run('Timed social progress persists without premature reward',social_restore)
 start(False)
 def narrator():
  h.ev('T.openTutorial36("sports39");');ensure('DeepShawn' in h.page.locator('#learnContent36').inner_text());ensure(h.ev('return T.tutorialLessons36.length===18;'))
 h.run('DeepShawn narrates an 18-chapter tutorial',narrator)
 h.run('Tutorial is isolated from formal study achievements',lambda:ensure(h.ev('const before=T.state.v39.correct.length;T.startTutorialPractice36();return T.state.v39.correct.length===before;')))
 start(False)
 def langtest():
  h.ev('T.settingChange({dataset:{setting:"language"},value:"en"});T.openTutorial36("study39");')
  ensure('Two question policies' in h.page.locator('#learnContent36').inner_text());h.ev('T.closeTutorial36();T.resume();')
  h.ev('T.testClear37();T.question("physics");')
  ensure(h.ev('return T.challenge.qid37.includes("v39");'))
  ensure(not any('\u4e00'<=x<='\u9fff' for x in h.page.locator('#challengeCard .challenge-description').inner_text()))
 h.run('English tutorial and new academic question displayed in English',langtest)
 h.run('Language switching does not reset a question',lambda:ensure(h.ev('const id=T.challenge.questionId38,r=T.challenge.remaining;T.settingChange({dataset:{setting:"language"},value:"zh-TW"});return T.challenge.questionId38===id&&T.challenge.remaining===r;')))
 start(False)
 def phone():
  h.page.set_viewport_size({'width':390,'height':844});h.ev('T.settingChange({dataset:{setting:"mobileMode"},checked:true});T.render();');ensure(h.page.locator('#phoneShell39').is_visible());h.page.screenshot(path=str(ROOT/'tests/phone390.png'))
  r=h.page.locator('#actionDock').bounding_box();ensure(r['width']<=390 and r['x']>=0,str(r));ensure(h.ev('return getComputedStyle(document.querySelector("#actionDock")).display==="grid";'))
 h.run('Phone layout reflows real action controls at 390×844',phone)
 h.run('Phone mode toggles back to desktop without losing state',lambda:ensure(h.ev('const id=T.state.runId;T.settingChange({dataset:{setting:"mobileMode"},checked:false});return T.state.runId===id&&document.querySelector("#stage #gameUI")!==null;')))
 # DeepShawn actual 14-stage challenge; agent knows answers and acts instantly.
 start(False,'god');free()
 def deep():
  r=h.ev('T.state.totalPhone=0;T.setAction("phone");for(let i=0;i<10;i++)T.advance(1);T.safeHide();T.beginDeep39();T.choose(0);let n=0;while(T.state.v39.deep.status==="active"&&n++<1000){const c=T.challenge;if(!c)throw new Error("missing deep challenge");if(c.type==="question"||c.type==="grid")T.number(c.correct);else if(c.type==="hide"){if(c.elapsed<c.grace)T.advance(c.grace-c.elapsed+.001);else T.reflexInput(c.layout.indexOf(c.sequence[c.step]));}else T.advance(.1);}return {status:T.state.v39.deep.status,right:T.state.v39.deep.right,phone:T.state.totalPhone,n,valid:T.validateSnapshot(T.captureSnapshot())!==null};')
  ensure(r['status']=='complete' and r['right']==14 and r['phone']>=10,str(r))
 h.run('Actual sealed trial: 8 chem + 3 grids + 2 rapid + 1 still',deep)
 def deep_end():
  r=h.ev('T.state.godElapsed=179.9;T.advance(.11);return {ending:T.state.endingId,wins:T.save.wins,ach:!!T.save.achievements.end_deepArchive39};')
  ensure(r=={'ending':'deepArchive39','wins':0,'ach':True},str(r))
 h.run('God special ending archives evidence without a graduation win',deep_end)
 start(False,'god');free()
 def failledger():
  h.ev('T.beginDeep39();T.choose(0);window.__beforeDeep=T.captureSnapshot();T.number((T.challenge.correct+1)%4);');ensure(h.ev('return T.state.v39.deep.failed&&T.save.deepTrialRuns39[T.state.runId].failed;'))
  h.ev('T.restore(window.__beforeDeep);T.resume();');ensure(h.ev('return T.state.v39.deep.status==="failed"&&!T.challenge?.deep39;'))
 h.run('Sealed trial failure survives checkpoint retry',failledger)
 h.run('No unhandled browser exceptions',lambda:ensure(not ERRORS,str(ERRORS)))
 b.close()
 out={'results':RESULTS,'pageErrors':ERRORS,'passed':sum(x['passed'] for x in RESULTS),'total':len(RESULTS)}
 (ROOT/'tests/v39_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('RESULT',out['passed'],out['total'])
 if out['passed']!=out['total']:raise SystemExit(1)
