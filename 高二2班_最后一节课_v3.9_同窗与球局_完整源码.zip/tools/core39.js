    // v3.9: run-local study policy, PE tracks, friendship routes and sealed archive.
    const BASE39={makeState,validateSnapshot,makeQuestionTiming38,deckDraw37,askQuestion,startGrid,
      scheduledEvents,dispatchEvent,dispatchContinuation,enterClass,enterCampusSlot,startNextWeekDay,
      finishQuestion,completeRapid,failHide,finishFreeze,godDefeat,updateCampus,startSport,
      update34,cancelDeskActivity,teacherRisky,rearRiskAction,headDownAction,finishTask34,
      achievementMetrics,checkAchievements,choose,renderUI,renderCampus,renderChallenge,
      renderModal,modalAction,settingChange,renderCharacters,renderTutorial36,tutorialCopy36,
      renderQuestionRules38,renderHome,returnMenu,restoreSnapshot,mergeAchievementProfile,
      showPack,clearTransient,renderDialogue,resize};
    const SPORTS39={badminton:{name:'羽毛球',en:'Badminton',drills:['发球练习','回球练习','双人对打'],enDrills:['Serve','Return','Rally']},basketball:{name:'篮球',en:'Basketball',drills:['运球练习','定点投篮','传球配合'],enDrills:['Dribble','Free throws','Passing']},pingpong:{name:'乒乓球',en:'Table tennis',drills:['握拍发球','正手攻球','连续对拉'],enDrills:['Serve','Forehand','Rally']}};
    const DEEP_STAGES39=['chem','chem','grid','rapid','chem','chem','freeze','grid','chem','chem','rapid','chem','chem','grid'];
    const LESSON_QUESTION_IDS39=new Set(['cnquestion','chemq1','chemq2','bioq','physq','physq2','engq1','engq2','engq3','mathq1','mathq2','mathgrid']);
    CAMPUS_CHALLENGES.push('peSelect39','pePartner39','social39','routes39','consent39','deepIntro39');
    CONTINUATIONS.push('deepNext39','gridSeries39');EVENT_IDS.push('casualQuestion39','gridQuestion39');
    Object.assign(ROLES,{'刘嗨':'PHYSICAL EDUCATION','DeepShawn':'CHEMISTRY REPRESENTATIVE / TUTOR','王梓锐':'SPORTS REPRESENTATIVE / FEMALE'});
    Object.assign(ENDINGS,V39_ENDINGS);ACHIEVEMENTS.push(...V39_ACHIEVEMENTS);
    function lang39(){return save?.settings?.language||'zh-CN';}
    function L39(zh,en){return lang39()==='en'?en:zh;}
    function day39(st=S){return Number(st?.calendar?.day||0);}
    function make39(st,study=false){return {version:1,study:!!study,gridDeck:[],lesson:{slot:'',oral:0,grids:0,gridRight:0,extra:0},
      pe:{slot:'',choice:null,partner:null,complete:false},sports:[],bonuses:0,
      correct:[],subjects:[],gridLessons:[],social:null,socialKeys:[],pengDays:[],pengTopics:[],pengConfirmed:false,
      wang:{affection:0,letters:0,chats:0,sport:0,discussed:[],days:[],letterDays:[],consent:false},
      romanceCaught:0,lastSocial:'',deep:{status:'idle',stage:0,right:0,ids:[],failed:false,started:0},
      gridSeries:null,explanation:'',migrated:false};}
    function ensure39(st=S,legacy=false){if(!st)return null;if(!st.v39){st.v39=make39(st,legacy?true:save.settings.studyMode);st.v39.migrated=legacy;if(legacy&&st.phase==='CAMPUS'&&st.campus?.location==='playground'&&(st.campus.pe?.done?.length||st.campus?.activity)){st.v39.pe={slot:String(st.campus.cursor),choice:'basketball',partner:'solo',complete:false};}}
      return st.v39;}
    function study39(st=S){return st?.v39?st.v39.study:!!save?.settings?.studyMode;}
    function recordUnique39(a,x){if(!a.includes(x))a.push(x);}
    function timeFlow39(st=S){return study39(st)?.65:1;}
    makeState=function(...a){const st=BASE39.makeState(...a);st.v39=make39(st,save.settings.studyMode);return st;};
    validateSnapshot=function(snap){if(snap?.state)ensure39(snap.state,true);BASE39.validateSnapshot(snap);
      const s=snap.state,v=s.v39,n=(x,max=1e7)=>Number.isFinite(x)&&x>=0&&x<=max;
      assertValid(v?.version===1&&typeof v.study==='boolean','学习模式记录损坏');
      for(const k of ['correct','subjects','sports','gridLessons','socialKeys','pengDays','pengTopics'])assertValid(Array.isArray(v[k])&&v[k].length<=5000,'新进度集合损坏：'+k);
      assertValid(v.correct.every(id=>QUESTION_INDEX38.has(id))&&new Set(v.correct).size===v.correct.length,'题目完成记录损坏');
      assertValid(v.subjects.every(id=>Object.hasOwn(QUESTIONS,id)),'学科记录损坏');
      assertValid(v.gridDeck.every(i=>Number.isInteger(i)&&i>=0&&i<GRID_BANK37.length)&&new Set(v.gridDeck).size===v.gridDeck.length,'编号题堆损坏');
      assertValid(v.pe&&(!v.pe.choice||Object.hasOwn(SPORTS39,v.pe.choice))&&[null,'peng','wang','solo'].includes(v.pe.partner)&&typeof v.pe.complete==='boolean','体育选择记录损坏');
      assertValid(v.sports.every(x=>x&&Object.hasOwn(SPORTS39,x.sport)&&n(x.day,6)&&typeof x.slot==='string'),'体育战绩损坏');
      assertValid(v.wang&&['affection','letters','chats','sport'].every(k=>n(v.wang[k],k==='affection'?100:1e6))&&Array.isArray(v.wang.discussed)&&Array.isArray(v.wang.days)&&Array.isArray(v.wang.letterDays)&&typeof v.wang.consent==='boolean','体委关系记录损坏');
      assertValid(v.deep&&['idle','active','complete','failed'].includes(v.deep.status)&&n(v.deep.stage,14)&&n(v.deep.right,14)&&Array.isArray(v.deep.ids)&&v.deep.ids.length<=14&&typeof v.deep.failed==='boolean','封存试炼损坏');
      if(v.social)assertValid(['wang','peng'].includes(v.social.target)&&['chat','letter','consent'].includes(v.social.type)&&n(v.social.elapsed,5)&&n(v.social.duration,5)&&v.social.elapsed<=v.social.duration&&n(v.social.roll,1),'互动记录损坏');
      if(v.gridSeries)assertValid(Number.isInteger(v.gridSeries.index)&&v.gridSeries.index>=0&&v.gridSeries.index<v.gridSeries.target&&[3,5].includes(v.gridSeries.target)&&CONTINUATIONS.includes(v.gridSeries.onDone),'编号连题记录损坏');
      for(const k of ['oral','grids','gridRight','extra'])assertValid(n(v.lesson[k],100),'课内配额损坏');
      assertValid(n(v.bonuses)&&n(v.romanceCaught),'新计数损坏');
      if(snap.challenge?.deep39)assertValid(s.difficulty==='god'&&v.deep.status==='active','封存试炼与周目不符');
      return snap;
    };
    mergeAchievementProfile=function(dst,src){BASE39.mergeAchievementProfile(dst,src);dst.deepTrialRuns39=dst.deepTrialRuns39||{};for(const [id,r] of Object.entries(src.deepTrialRuns39||{})){if(r?.failed)dst.deepTrialRuns39[id]={failed:true};}};
    restoreSnapshot=function(...a){const result=BASE39.restoreSnapshot(...a);if(S){const v=ensure39(S,true);if(save.deepTrialRuns39?.[S.runId]?.failed){v.deep.failed=true;v.deep.status='failed';if(challenge?.deep39)closeChallenge();}}return result;};
    startNextWeekDay=function(){const old=S?.v39?clone(S.v39):null;const id=S?.runId;BASE39.startNextWeekDay();if(S&&old&&S.runId===id){const next=ensure39();for(const k of ['study','sports','bonuses','correct','subjects','gridLessons','socialKeys','pengDays','pengTopics','pengConfirmed','wang','romanceCaught','deep'])next[k]=clone(old[k]);next.social=null;next.gridSeries=null;requestAutoSave();}};
    makeQuestionTiming38=function(id,st=S,context='oral',repeat=1){const t=BASE39.makeQuestionTiming38(id,st,context,repeat);if(study39(st)){t.policy39='study';return t;}
      const budget=({oral:12,exam:14,memory:12,grid:16,mirror:16,route:12})[context];
      return {...t,bonus:0,hearing:0,total:roundTime38(budget*t.multiplier),budget39:budget,policy39:'casual'};
    };
    timingFormula38=function(t){if(t.legacy)return L39('旧记录本题保留原时限','This saved question retains its original limit');if(t.policy39==='casual')return L39('休闲固定预算','Casual fixed budget')+' '+t.budget39+'s × '+t.multiplier.toFixed(2)+' = '+t.total.toFixed(1)+'s';const raw=t.normal+t.bonus+t.hearing;return L39('学习分级预算','Graded study budget')+' ('+t.normal+' + '+(t.bonus+t.hearing)+')s × '+t.multiplier.toFixed(2)+' = '+t.total.toFixed(1)+'s';};
    timingPanel38=function(c){const t=c.timing38;if(!t)return '';return `<section class="question-timing38"><div><b>${L39(t.policy39==='casual'?'休闲模式':'学习模式',t.policy39==='casual'?'CASUAL':'STUDY')} · L${t.grade||'?'}</b><span>${L39('时限','Limit')} ${t.total.toFixed(1)}s</span></div><details><summary>${esc(timingFormula38(t))}</summary><p>${L39('休闲：固定短时限，主要抽基础题；学习：按等级补时。标准／快速课时不再重复缩短题目时间。','Casual uses short fixed limits and basic questions. Study uses graded reading time. Quick lessons do not apply a second question-time reduction.')}</p><small>${esc(t.id)}</small></details></section>`;};
    let forcedQuestion39=null;
    deckDraw37=function(subject){const bank=QUESTIONS[subject];if(forcedQuestion39?.subject===subject){const i=forcedQuestion39.index;forcedQuestion39=null;return i;}
      const v=ensure37(),eligible=i=>bank[i]&&(study39()||bank[i].grade38<=2)&&(lang39()!=='en'||!!bank[i].en39);
      let deck=(v.decks[subject]||[]).filter(eligible);if(!deck.length)deck=shuffle(bank.map((_,i)=>i).filter(eligible));
      if(!deck.length)deck=shuffle(bank.map((_,i)=>i));const index=deck.pop();v.decks[subject]=deck;return index;};
    askQuestion=function(subject,number=0,onDone=null){const v=ensure39();const ordinary=S?.phase==='CLASS'&&!onDone&&!forcedQuestion39&&!S?.v34?.test;
      if(ordinary&&!study39()&&v.lesson.oral>=1)return;
      BASE39.askQuestion(subject,number,onDone);
      if(challenge?.type==='question'&&ordinary)v.lesson.oral++;
      if(challenge?.type==='question')renderChallenge();
    };
    function nextGrid39(onDone=null,deep=false){const v=ensure39();let ids=v.gridDeck.filter(i=>GRID_BANK37[i]&&(deep||study39()||GRID_BANK37[i].grade38<=2)&&(lang39()!=='en'||GRID_BANK37[i].en39));
      if(!ids.length)ids=shuffle(GRID_BANK37.map((_,i)=>i).filter(i=>(deep||study39()||GRID_BANK37[i].grade38<=2)&&(lang39()!=='en'||GRID_BANK37[i].en39)));
      const i=ids.pop();v.gridDeck=ids;const q=GRID_BANK37[i],t=makeQuestionTiming38(q.id38,S,'grid'),g=deep?0:learningGlow37();
      beginChallenge({type:'grid',questionId38:q.id38,timing38:t,remaining:t.total,title:'1 / 56',description:q.q,numbers:shuffle(Array.from({length:56},(_,i)=>i+1)),correct:q.n,explain:q.e,math:!deep,hint:g>0,glow37:g,hintDuration:3.2,onDone,kicker:deep?'DEEPSHAWN / SEALED TEST':(S.phase==='ESCAPE'?'FINAL LOCK':'MATH / '+(v.lesson.grids||1)),deep39:deep});
      if(deep)recordUnique39(v.deep.ids,q.id38);requestAutoSave();return challenge;}
    startGrid=function(onDone=null){const v=ensure39();if(challenge||script)return;if(S.phase==='ESCAPE'&&onDone&&onDone!=='gridSeries39'&&onDone!=='deepNext39'){
        v.gridSeries={index:0,target:study39()?5:3,onDone};return nextGrid39('gridSeries39');}
      return nextGrid39(onDone);};
    scheduledEvents=function(){if(!S||S.phase!=='CLASS')return;const v=ensure39(),l=S.v34.lesson,ratio=S.elapsed/S.duration,subject=CLASSES[S.classIndex].id;
      for(const [at,id] of LESSON_EVENTS[subject]||[]){if(id==='mathgrid')continue;if(!study39()&&LESSON_QUESTION_IDS39.has(id))continue;if(ratio>=at&&!S.eventsDone.includes(id))enqueue(id,id);}
      if(S.classIndex>=6)return;
      if(!study39()&&ratio>=.43&&v.lesson.extra<1){v.lesson.extra=1;enqueue('casual39','casualQuestion39');}
      if(study39()){const ats=[.12,.36,.59,.82];if(l.extra<4&&ratio>=ats[l.extra]){l.extra++;enqueue('study39-'+l.extra,'extraQuestion34');}}
      if(S.classIndex===5){const ats=study39()?[.20,.34,.48,.62,.76]:[.30,.53,.76];if(v.lesson.grids<ats.length&&ratio>=ats[v.lesson.grids]){v.lesson.grids++;enqueue('grid39-'+v.lesson.grids,'gridQuestion39');}}
      if(l.cleanPlanned&&!S.v34.cleanChecked.includes(l.slot)&&ratio>=l.cleanAt){S.v34.cleanChecked.push(l.slot);enqueue('clean34-'+l.slot,'hygiene34');}
      if(l.double&&!l.testDone&&ratio>=.07&&!challenge&&!script){l.testDone=true;enqueue('test34-'+l.slot,'doubleTest34');}
    };
    dispatchEvent=function(id){if(id==='casualQuestion39'){askQuestion(CLASSES[S.classIndex].id);return;}if(id==='gridQuestion39'){nextGrid39();return;}return BASE39.dispatchEvent(id);};
    enterClass=function(...a){BASE39.enterClass(...a);if(S){const v=ensure39();v.lesson={slot:String(S.campus.cursor)+'-'+day39(),oral:0,grids:0,gridRight:0,extra:0};v.social=null;requestAutoSave();}};
    enterCampusSlot=function(...a){BASE39.enterCampusSlot(...a);if(S&&campusSlot()?.kind==='pe'){const v=ensure39(),slot=String(day39())+'-'+S.campus.cursor;if(v.pe.slot!==slot)v.pe={slot,choice:null,partner:null,complete:false};if(!script&&!challenge)selectPE39();}};
    dispatchContinuation=function(id,ok){if(id==='deepNext39'){deepAdvance39(!!ok);return;}if(id==='gridSeries39'){const v=ensure39(),series=v.gridSeries;if(!series)return;series.index++;if(series.index<series.target){nextGrid39('gridSeries39');}else{const done=series.onDone;v.gridSeries=null;BASE39.dispatchContinuation(done,ok);}return;}
      const result=BASE39.dispatchContinuation(id,ok);if(id==='campusReady'&&S?.screen==='game'&&campusSlot()?.kind==='pe'&&!ensure39().pe.choice&&!challenge&&!script)selectPE39();return result;};
    function selectPE39(){if(!S||challenge||script||campusSlot()?.kind!=='pe')return;beginChallenge({type:'peSelect39',title:L39('刘嗨 · 体育项目选择','Liu Hai · Choose a PE track'),description:L39('这节课先选一个项目，再完成该项目的三段练习。选择后，本节不换项目。','Choose one track, then complete its three drills. Your choice remains fixed for this PE lesson.'),choices:Object.values(SPORTS39).map(s=>L39(s.name,s.en)),kicker:'PHYSICAL EDUCATION'});}
    function selectPEPartner39(){beginChallenge({type:'pePartner39',title:L39('选择练习搭档','Choose a practice partner'),description:L39('羽毛球且开启对应攻略：完成整节三段练习额外增加8好感、恢复6专注。普通友情搭档仍可选择，不要求攻略。','Badminton with that partner’s romance enabled grants +8 affection and +6 focus after all three drills. Friendship partners remain available without romance.'),choices:[L39('彭望梓 · 班长','Peng Wangzi · monitor'),L39('王梓锐 · 体委','Wang Zirui · sports rep'),L39('独自练习','Practise independently')]});}
    startSport=function(id){if(!canAct()||!campusFree()||campusSlot()?.kind!=='pe'||!['run','ball','walk'].includes(id))return;const v=ensure39();if(!v.pe.choice){selectPE39();return;}if(S.campus.activity||S.campus.pe.done.includes(id))return;
      safeHide();S.campus.activity={id,remaining:6};const i=['run','ball','walk'].indexOf(id),sport=SPORTS39[v.pe.choice];say('刘嗨',L39(sport.name+'：'+sport.drills[i]+'。先站稳，别着急。',sport.en+': '+sport.enDrills[i]+'. Balance first; do not rush.'));requestAutoSave();renderCampus();};
    function completeSport39(){const v=ensure39(),p=v.pe;if(p.complete||!p.choice||S.campus.pe.done.length<3)return;p.complete=true;
      v.sports.push({day:day39(),slot:p.slot,sport:p.choice,partner:p.partner});
      if(p.partner==='wang'){v.wang.sport++;v.wang.affection=clamp(v.wang.affection+10);recordUnique39(v.wang.days,day39());}
      if(p.partner==='peng'){recordUnique39(v.pengDays,day39());S.v34.peng.affection=clamp(S.v34.peng.affection+10);if(p.choice==='badminton')S.v34.peng.badminton++;}
      const bonus=p.choice==='badminton'&&((p.partner==='peng'&&save.settings.pengRoute)||(p.partner==='wang'&&save.settings.wangRoute));
      if(bonus){v.bonuses++;S.focus=clamp(S.focus+6);const r=p.partner==='wang'?v.wang:S.v34.peng;r.affection=clamp(r.affection+8);toast(L39('羽毛球默契加成 · 好感 +8 · 专注 +6','Badminton chemistry · affection +8 · focus +6'));}
      say('刘嗨',L39('今天这一项的三段练习完成了。自由活动，注意安全。','All three drills are complete. Enjoy your free time and stay safe.'));checkAchievements();requestAutoSave();}
    updateCampus=function(dt){BASE39.updateCampus(dt);if(S?.screen==='game'&&campusSlot()?.kind==='pe')completeSport39();};
    // New interactions are timed in the live classroom; the selection menu is not the action.
    function showSocial39(target='wang',page=0){if(!canAct()||!['CLASS','CAMPUS'].includes(S.phase))return;const r=target==='wang'?ensure39().wang:S.v34.peng,on=target==='wang'?save.settings.wangRoute:save.settings.pengRoute;
      const labels=page===0?[L39('聊运动','Talk about sport'),L39('聊零食','Talk about snacks'),L39('聊相处边界','Discuss boundaries'),L39('下一页','Next page')]:[L39('提醒休息','Talk about rest'),L39('递情书','Give a letter'),L39('确认彼此心意','Ask about mutual feelings'),L39('返回','Back')];
      beginChallenge({type:'social39',target39:target,page39:page,title:(target==='wang'?'王梓锐':'彭望梓')+' · '+L39('互动','Conversation'),description:L39('好感 '+Math.round(r.affection)+'/100。说完才结算，每种话题每天一次。课堂私聊会引起老师关注，空格可收声。','Affection '+Math.round(r.affection)+'/100. Rewards apply only after the conversation. Each topic counts once per day. Classroom chats can attract attention; Space stops the action.'),choices:labels,locks:page===1?[null,on?null:L39('先在设置开启此人物攻略','Enable this romance in Settings'),on?null:L39('攻略未开启','Romance is off'),null]:undefined});}
    function socialAction39(target,type,key=''){if(!canAct()||!['CLASS','CAMPUS'].includes(S.phase)||S.campus.location==='office')return false;const v=ensure39(),on=target==='wang'?save.settings.wangRoute:save.settings.pengRoute;if(!['wang','peng'].includes(target)||!['chat','letter','consent'].includes(type))return false;
      if(type!=='chat'&&!on){toast(L39('该人物的攻略尚未开启','This romance is disabled'));return false;}
      if(type==='consent'){if(!campusFree()){toast(L39('等课间再认真谈这件事','Discuss this during a break'));return false;}const r=target==='wang'?v.wang:S.v34.peng;if(r.affection<55||r.letters<1){toast(L39('先互相了解，并送达至少一封信','Get to know each other and deliver a letter first'));return false;}
        beginChallenge({type:'consent39',target39:target,title:L39('把话说清楚','Make your intentions clear'),description:L39('“我愿意继续了解你，但不希望你替我决定。你也这样想吗？”','“I would like to get to know you, but please do not decide for me. Do you feel the same?”'),choices:[L39('愿意，尊重彼此的时间与边界','Yes — respect each other’s time and boundaries'),L39('现在只做朋友','Stay friends for now')]});return true;}
      const token=day39()+':'+target+':'+type+':'+key;if(v.socialKeys.includes(token)){toast(L39('今天已经完成这项互动，换一个话题吧','This interaction has already counted today'));return false;}
      safeHide();cancelDeskActivity('switch');S.action='listen';v.social={target,type,key,token,elapsed:0,duration:type==='letter'?5:4,roll:random37(),warned:false};
      say(target==='wang'?'王梓锐':'彭望梓',L39(type==='letter'?'“等你把信放好，我会认真读的。”':({sport:'“下次练球一起？先热身喵。”',snack:'“这份是我的。你可以问我，但不许突然拿走喵。”',boundary:'“当然，喜欢也要先问。我们都可以说不。”',rest:'“谢谢提醒。我也不用一直替所有人望风。”'})[key],type==='letter'?'“I will read it carefully when you hand it over.”':({sport:'“Practise together next time? Warm up first, meow.”',snack:'“This is mine. You can ask, but do not snatch it, meow.”',boundary:'“Of course. Ask first. Either of us can say no.”',rest:'“Thank you. I do not have to keep watch for everyone all the time.”'})[key]));requestAutoSave();return true;}
    function updateSocial39(dt){const v=ensure39(),t=v.social;if(!t)return;
      if(S.phase==='CLASS'){if(t.elapsed>=.9&&!t.warned){t.warned=true;if(t.roll<Math.min(.7,.22+rules().rank*.07))toast(L39('讲台上的目光移了过来，空格收声','The teacher is looking over. Space stops the conversation.'),true,2);}
        if(t.warned&&t.elapsed>=2.2&&t.roll<Math.min(.7,.22+rules().rank*.07)){v.social=null;v.romanceCaught++;S.v34.incidents++;addSuspicion(18);campusRecord('课堂私聊／传信被确认。');say(CLASSES[S.classIndex].teacher,L39('下课再聊，不要影响别人。','Talk after class. Do not interrupt others.'));requestAutoSave();return;}}
      t.elapsed=Math.min(t.duration,t.elapsed+dt);if(t.elapsed<t.duration)return;
      v.social=null;recordUnique39(v.socialKeys,t.token);const r=t.target==='wang'?v.wang:S.v34.peng;r.affection=clamp(r.affection+(t.type==='letter'?12:8));
      if(t.type==='letter'){r.letters++;if(t.target==='wang')recordUnique39(r.letterDays,day39());}
      else{r.chats++;recordUnique39(r.discussed,t.key);if(t.target==='peng')recordUnique39(v.pengTopics,t.key);}
      recordUnique39(t.target==='wang'?r.days:v.pengDays,day39());v.lastSocial=t.target+':'+t.type;
      toast(L39('互动完成 · 关系进度已保存','Interaction completed · relationship progress saved'));checkAchievements();requestAutoSave();}
    cancelDeskActivity=function(reason='switch'){if(S?.v39?.social){S.v39.social=null;toast(L39('你收住了话，没有领取未完成互动的收益','Conversation stopped; no unfinished reward granted'));}return BASE39.cancelDeskActivity(reason);};
    teacherRisky=function(){return !!S?.v39?.social||BASE39.teacherRisky();};
    rearRiskAction=function(){return S?.v39?.social?(S.v39.social.type==='letter'?'note':'talk'):BASE39.rearRiskAction();};
    headDownAction=function(){return !!S?.v39?.social||BASE39.headDownAction();};
    update34=function(dt){if(S?.screen==='game'&&!challenge&&!script&&!modal&&S.v39?.social)updateSocial39(dt);return BASE39.update34(dt);};
    finishTask34=function(){const t=S?.v34?.task?clone(S.v34.task):null;BASE39.finishTask34();if(t&&S?.v39&&['pengTalk','letter','pengHelp','badminton'].includes(t.type)){recordUnique39(S.v39.pengDays,day39());for(const k of S.v34.peng.discussed)recordUnique39(S.v39.pengTopics,k);checkAchievements();}};
    function beginDeep39(){if(!canAct()||!campusFree()||S.difficulty!=='god')return false;const v=ensure39();if(v.deep.status!=='idle'||save.deepTrialRuns39?.[S.runId]?.failed){toast(L39('此周目的封存挑战已使用，不能靠回档重置','This run’s sealed attempt has been used; reloading cannot reset it'));return false;}
      beginChallenge({type:'deepIntro39',title:'DeepShawn · '+L39('第181页','Page 181'),description:L39('“女神”不是出口。你要在180秒闭环内，无失误完成8道L3/L4化学、3道56选一、2次六键快速反应、1次静止；并在真实自由时间用手机10秒。任一失误永久封存本周目。成功只保存档案，不能离校。','The “Goddess” offers no escape. Within the 180-second loop: 8 L3/L4 chemistry questions, 3 number grids, 2 flawless six-key reactions, and 1 flawless stillness test; plus 10 seconds of real phone use. Any error seals this run permanently. Success preserves an archive, not an exit.'),choices:[L39('接受唯一一次尝试','Accept the one attempt'),L39('先做准备','Prepare first')]});return true;}
    function deepFail39(){if(!S||S.v39?.deep.failed)return;const v=ensure39();v.deep.status='failed';v.deep.failed=true;save.deepTrialRuns39=save.deepTrialRuns39||{};save.deepTrialRuns39[S.runId]={failed:true};saveProfile();toast(L39('封存挑战失败 · 本周目回档不会重置','Sealed trial failed · checkpoint retries cannot reset it'),true,5);requestAutoSave();}
    function nextDeep39(){const v=ensure39(),d=v.deep;if(d.status!=='active'||challenge||script)return;
      if(d.stage>=DEEP_STAGES39.length){d.status='complete';say('DeepShawn',L39('十四项都完成了。还要真实用手机十秒，然后等闭环到来。我们留下证据，不假装已经逃出去。','All fourteen stages are complete. Use the phone for ten real seconds, then face the loop. We preserve evidence; we do not pretend to escape.'));checkAchievements();requestAutoSave();return;}
      const kind=DEEP_STAGES39[d.stage];if(kind==='chem'){const bank=QUESTIONS.chemistry,ids=bank.map((q,i)=>i).filter(i=>bank[i].grade38>=3&&!d.ids.includes(bank[i].id37)&&(lang39()!=='en'||bank[i].en39));const i=ids[Math.floor(random37()*ids.length)];forcedQuestion39={subject:'chemistry',index:i};askQuestion('chemistry',i,'deepNext39');challenge.deep39=true;challenge.hearing34=1;challenge.heard34=0;challenge.math=false;applyQuestionTiming38(challenge);recordUnique39(d.ids,bank[i].id37);}
      else if(kind==='grid')nextGrid39('deepNext39',true);
      else if(kind==='rapid'){const c=createRapidChallenge(S,{tutorial:false,wasPhone:false,wasSleep:false,wasNote:false,wasTalk:false,wasChess:false,parent:false});c.deep39=true;beginChallenge(c);}
      else{startFreeze('deepNext39');challenge.deep39=true;}
      if(challenge){challenge.kicker='DEEPSHAWN / '+(d.stage+1)+' / 14';renderChallenge();}requestAutoSave();}
    function deepAdvance39(ok){const d=ensure39().deep;if(d.status!=='active')return;if(!ok){deepFail39();return;}d.right++;d.stage++;nextDeep39();}
    completeRapid=function(){const c=challenge?clone(challenge):null;BASE39.completeRapid();if(c?.deep39)deepAdvance39(c.slips===0);};
    failHide=function(){const deep=!!challenge?.deep39;BASE39.failHide();if(deep)deepFail39();};
    finishFreeze=function(ok){if(challenge?.deep39&&challenge.slips>0)ok=false;return BASE39.finishFreeze(ok);};
    finishQuestion=function(index){const c=challenge?clone(challenge):null;if(!c)return;const before=S?.questionRight||0;const deep=!!c.deep39;
      // Count after the final response only; the continuation may already have generated another question.
      if(deep&&c.questionId38)recordUnique39(S.v39.deep.ids,c.questionId38);BASE39.finishQuestion(index);if(!S?.v39)return;const v=S.v39,ok=index===c.correct&&(S.questionRight>before);
      if(ok&&c.questionId38){recordUnique39(v.correct,c.questionId38);const q=QUESTION_INDEX38.get(c.questionId38);if(q)recordUnique39(v.subjects,q.subject);
        if(c.type==='grid'&&S.phase==='CLASS'&&!deep){v.lesson.gridRight++;const target=study39()?5:3;if(v.lesson.gridRight===target)recordUnique39(v.gridLessons,(study39()?'study:':'casual:')+day39()+':'+v.lesson.slot);}}
      if(deep&&index!==c.correct)deepFail39();checkAchievements();requestAutoSave();};
    function deepEligible39(st=S){const v=st?.v39,d=v?.deep;return !!st&&st.difficulty==='god'&&d?.status==='complete'&&d.right===14&&!d.failed&&!save.deepTrialRuns39?.[st.runId]?.failed&&st.questionWrong===0&&st.dangerFails===0&&st.caught===0&&st.phoneCaught===0&&st.totalPhone>=10&&st.godElapsed>=GOD_LIMIT;}
    godDefeat=function(reason='clock'){if(reason==='clock'&&deepEligible39()){finishEnding('deepArchive39');return;}return BASE39.godDefeat(reason);};
    function metrics39(){const v=S?.v39;if(!v)return {};const p=S.v34.peng,w=v.wang,subjects=v.subjects.filter(s=>s!=='chinese').length;
      return {peBadminton39:v.sports.filter(x=>x.sport==='badminton').length,peBasket39:v.sports.filter(x=>x.sport==='basketball').length,pePing39:v.sports.filter(x=>x.sport==='pingpong').length,peBonus39:v.bonuses,threeSports39:new Set(v.sports.map(x=>x.sport)).size,
      wangTalk39:w.chats,wangBoundary39:w.discussed.includes('boundary')?1:0,wangLetter39:w.letters,wang60:w.affection,peng85:p.affection,differentDays39:v.pengDays.length,
      studyFirst39:v.study?v.correct.length:0,study30:v.study?v.correct.length:0,study100:v.study?v.correct.length:0,fiveSubjects39:v.study?subjects:0,
      threeGrid39:v.gridLessons.filter(x=>x.startsWith('casual:')).length,fiveGrid39:v.gridLessons.filter(x=>x.startsWith('study:')).length,
      deepTrial39:v.deep.status!=='idle'?1:0,deepProof39:v.deep.right,all39:save.endings.filter(id=>ENDING_IDS.includes(id)).length};}
    achievementMetrics=function(endingId=null){return {...BASE39.achievementMetrics(endingId),...metrics39()};};
    function routeOptions39(){const v=ensure39(),p=S.v34.peng,w=v.wang,on=save.settings.pengRoute,wo=save.settings.wangRoute,confirm=v.pengConfirmed||p.consent;
      return [
        ['pengRally39',on&&p.affection>=65&&p.letters>=1&&p.badminton>=2&&confirm],
        ['pengSnack39',on&&p.affection>=60&&p.chats>=3&&v.pengTopics.includes('snack')&&v.pengTopics.includes('boundary')&&confirm],
        ['pengStudy39',on&&v.study&&p.affection>=70&&v.correct.length>=12&&v.subjects.length>=3&&p.letters>=1&&confirm],
        ['pengTomorrow39',on&&S.calendar.mode==='week'&&day39()===6&&p.affection>=85&&p.letters>=3&&v.pengDays.length>=3&&confirm],
        ['wangFriend39',w.discussed.length>=2&&w.sport>=1],
        ['wangPromise39',wo&&w.affection>=60&&w.letters>=1&&w.sport>=1&&w.discussed.includes('boundary')&&w.consent],
        ['wangTrust39',wo&&w.affection>=85&&w.letters>=2&&w.sport>=2&&w.discussed.includes('boundary')&&w.discussed.includes('rest')&&w.consent],
        ['scholar39',v.study&&v.correct.length>=30&&v.subjects.filter(x=>x!=='chinese').length>=5&&v.gridLessons.some(x=>x.startsWith('study:'))],
        ['sportsAll39',S.calendar.mode==='week'&&new Set(v.sports.map(x=>x.sport)).size===3]
      ].map(([id,ok])=>({id,ok:!!ok&&S.difficulty!=='god'}));}
    function showRoutes39(page=0){if(S?.phase!=='COMPLETE')return;const items=routeOptions39().slice(page*3,page*3+3);beginChallenge({type:'routes39',page39:page,ids39:items.map(x=>x.id),title:L39('放学后的新约定','New plans after the last bell'),kicker:'21:40 / ROUTES',description:items.map(x=>L39(V39_ENDINGS[x.id].title,V39_ENDINGS[x.id].en39.title)+'：'+L39(V39_ENDINGS[x.id].hint,V39_ENDINGS[x.id].en39.hint)).join('\n'),choices:[...items.map(x=>L39(V39_ENDINGS[x.id].title,V39_ENDINGS[x.id].en39.title)),page<2?L39('下一页','Next page'):L39('返回离校选择','Return to departure')],locks:[...items.map(x=>x.ok?null:L39('条件尚未满足','Requirements not met')),null]});}
    choose=function(index){const c=challenge;if(!c||modal||recoveryGrace>0||!Number.isInteger(index)||index<0||index>=(c.choices?.length||0)||c.locks?.[index])return BASE39.choose(index);
      if(c.type==='peSelect39'){ensure39().pe.choice=Object.keys(SPORTS39)[index];closeChallenge();selectPEPartner39();return;}
      if(c.type==='pePartner39'){ensure39().pe.partner=['peng','wang','solo'][index];closeChallenge();say('刘嗨',L39('选好了就开始练习。三个项目都可以，不必和别人选一样。','Start practising. All three tracks are valid; you need not follow everyone else.'));renderCampus();requestAutoSave();return;}
      if(c.type==='social39'){const target=c.target39,page=c.page39;closeChallenge();if(index===3){showSocial39(target,1-page);return;}const key=page===0?['sport','snack','boundary'][index]:['rest','',''][index];socialAction39(target,page===1&&index===1?'letter':page===1&&index===2?'consent':'chat',key);return;}
      if(c.type==='consent39'){const t=c.target39;closeChallenge();if(t==='wang')ensure39().wang.consent=index===0;else{ensure39().pengConfirmed=index===0;S.v34.peng.consent=index===0;}say(t==='wang'?'王梓锐':'彭望梓',L39(index===0?'“那就慢慢来，喵。我们一起决定。”':'“好，朋友也很好。”',index===0?'“Then let us take it slowly, meow. We decide together.”':'“All right. Friendship matters too.”'));requestAutoSave();return;}
      if(c.type==='routes39'){const p=c.page39,id=c.ids39[index];if(index<3&&id){if(!routeOptions39().find(x=>x.id===id)?.ok)return;closeChallenge();finishEnding(id);}else{closeChallenge();if(p<2)showRoutes39(p+1);else showPack();}return;}
      if(c.type==='deepIntro39'){closeChallenge();if(index===0){const d=ensure39().deep;d.status='active';d.started=S.godElapsed;nextDeep39();}requestAutoSave();return;}
      return BASE39.choose(index);
    };

const beginChallengeBefore39=beginChallenge;
beginChallenge=function(c){if(c?.onDone==='deepNext39'&&S?.v39?.deep.status==='active')c.deep39=true;return beginChallengeBefore39(c);};
const exposureBefore39=questionExposure38;
questionExposure38=function(c,dt){const exposure=exposureBefore39(c,dt);return c?.type==='grid'&&S?.v39?.gridSeries?exposure/S.v39.gridSeries.target:exposure;};
