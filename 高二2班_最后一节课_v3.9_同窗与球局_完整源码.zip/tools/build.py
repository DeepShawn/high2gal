from pathlib import Path
import json,re,subprocess
W=Path(__file__).resolve().parent; out=W.parent;out.mkdir(exist_ok=True)
s=(out/'tests/fixtures/v3.8.html').read_text(encoding='utf-8')
data=(W/'data39.js').read_text(encoding='utf-8')
s=s.replace('    const ENDING_IDS =',data+'\n    const ENDING_IDS =',1)
s=s.replace('...Object.keys(V34_ENDINGS),...Object.keys(V37_ENDINGS)];','...Object.keys(V34_ENDINGS),...Object.keys(V37_ENDINGS),...Object.keys(V39_ENDINGS)];',1)
s=s.replace("...Object.keys(V37_ENDINGS).filter(id=>id!=='realEmpty37')];","...Object.keys(V37_ENDINGS).filter(id=>id!=='realEmpty37'),...Object.keys(V39_ENDINGS).filter(id=>id!=='deepArchive39')];",1)
s=s.replace('...V37_ACHIEVEMENTS.map(x=>x.id),...ENDING_IDS.map','...V37_ACHIEVEMENTS.map(x=>x.id),...V39_ACHIEVEMENTS.map(x=>x.id),...ENDING_IDS.map',1)
s=s.replace('Object.assign(ENDINGS,V34_ENDINGS);','Object.assign(ENDINGS,V34_ENDINGS,V39_ENDINGS);',1)
s=s.replace('realRuns37:{}, godBest:','realRuns37:{}, deepTrialRuns39:{}, godBest:',1)
s=s.replace("settings: { difficulty: 'normal',","settings: { language:'zh-CN',mobileMode:false,studyMode:false,wangRoute:false, difficulty: 'normal',",1)
s=s.replace("'pengRoute', 'realMode', 'dialogueVoice']","'pengRoute', 'realMode', 'dialogueVoice','studyMode','mobileMode','wangRoute']",1)
s=s.replace("        const vol = Number(raw.settings?.volume ?? .35);","""        if(['zh-CN','zh-TW','en'].includes(raw.settings?.language))out.settings.language=raw.settings.language;
        for(const [id,x] of Object.entries(raw.deepTrialRuns39||{}).slice(-100))if(/^[A-Za-z0-9_.:-]{1,120}$/.test(id)&&!['__proto__','constructor','prototype'].includes(id)&&x?.failed===true)out.deepTrialRuns39[id]={failed:true};
        const vol = Number(raw.settings?.volume ?? .35);""",1)
# The v3.8 catalog is immutable; extend source banks before it is constructed.
questions=json.loads((W/'questions39.json').read_text(encoding='utf-8')); grids=json.loads((W/'grid39.json').read_text(encoding='utf-8'))
bankjs='\nconst ADDED_QUESTIONS39='+json.dumps(questions,ensure_ascii=False,separators=(',',':'))+';\nObject.entries(ADDED_QUESTIONS39).forEach(([s,a])=>QUESTIONS[s].push(...a));\nGRID_BANK37.push(...'+json.dumps(grids,ensure_ascii=False,separators=(',',':'))+');\n'
s=s.replace('    const QUESTION_CATALOG38=Object.freeze([',bankjs+'\n    const QUESTION_CATALOG38=Object.freeze([',1)
# Flow slowing only affects classroom elapsed clock, never reaction inputs or question timers.
s=s.replace('S.elapsed=Math.min(S.duration,S.elapsed+dt);S.survival+=dt;updateTeacher(dt);return;', 'S.elapsed=Math.min(S.duration,S.elapsed+dt*timeFlow39());S.survival+=dt;updateTeacher(dt);return;')
s=s.replace('S.elapsed = Math.min(S.duration, S.elapsed + dt);','S.elapsed = Math.min(S.duration, S.elapsed + dt*timeFlow39());')
s=s.replace('(campusFree()&&!challenge)))','(campusFree()&&(!challenge||challenge.deep39))))')
# Additional lesson chapters must precede freeze of chapter catalog.
s=s.replace("        {id:'save',label:'存档与开始实战'", "        {id:'study39',label:'学习与休闲模式',title:'题量和计时由学习开关决定。'},\n        {id:'sports39',label:'体育与攻略人物',title:'练完一节课，再收获默契。'},\n        {id:'deep39',label:'DeepShawn与封存试炼',title:'第181页，不等于第181秒。'},\n        {id:'platform39',label:'语言与手机端',title:'同一周目，切换语言与布局。'},\n        {id:'save',label:'存档与开始实战'",1)
# Gender/PE display updates; no changes to IDs used in saves.
s=s.replace("['王梓锐','男'","['王梓锐','女'")
s=s.replace("'体育老师'", "'刘嗨'").replace('由体育老师任教','由刘嗨老师任教').replace('体育老师：','刘嗨：')
s=s.replace('等他醒来','等她醒来').replace('体育／值班教师均为女性','体育教师刘嗨／值班教师均为女性')
s=s.replace("v[k].length<=1000","v[k].length<=5000")
s=s.replace('体育老师 / 自由活动','刘嗨 / 自由活动')
s=s.replace('慢跑、投篮、散步，或者找同学下棋。','先选羽毛球、篮球或乒乓球，再完成三段练习；之后可以自由活动。')
s=s.replace('完成慢跑、投篮、散步三种活动','完成所选体育项目的三段练习')
s=s.replace('完成慢跑、投篮和散步','完成所选体育项目的三段练习')
s=s.replace('function localVoice37(){try{return window.speechSynthesis?.getVoices().find(v=>v.localService&&/^zh(?:-|_|$)/i.test(v.lang))||null;}catch(_){return null;}}',
'''function localVoice37(text=''){try{const code=save?.settings?.language==='en'&&!/[\u3400-\u9fff]/.test(text)?'en':'zh';return window.speechSynthesis?.getVoices().find(v=>v.localService&&v.lang.toLowerCase().startsWith(code))||null;}catch(_){return null;}}''')
s=s.replace('const voice=localVoice37();if(!voice)', 'const voice=localVoice37(text);if(!voice)')
s=s.replace('未找到本地中文语音；请在系统安装中文语音包。文字可正常继续。','未找到对应语言的本地语音；文字仍可正常继续。')
s=s.replace('单文件离线版　3.6','单文件离线版　3.9')
s=re.sub(r'<title>.*?</title>','<title>高二（2）班：最后一节课 · v3.9 同窗与球局</title>',s,count=1)
core=(W/'core39.js').read_text(encoding='utf-8').replace('saveProfile();','persist();')
core=core.replace("if(ratio>=at&&!S.eventsDone.includes(id))enqueue(id,id);","if(ratio>=at&&!S.eventsDone.includes(id)){S.eventsDone.push(id);enqueue(id,id);}")
# Add a validated save-policy indicator without silently changing a loaded question.
parts=[(W/'i18n39.js').read_text(encoding='utf-8') if (W/'i18n39.js').exists() else '',core,(W/'ui39.js').read_text(encoding='utf-8'),(W/'mobile39.js').read_text(encoding='utf-8') if (W/'mobile39.js').exists() else 'function syncMobile39(){}\nfunction localize39(){}']
s=s.replace('    // The classroom is a layered DOM illustration rather than a raster image.', '\n'.join(parts)+'\n    // The classroom is a layered DOM illustration rather than a raster image.',1)
css=(W/'style39.css').read_text(encoding='utf-8') if (W/'style39.css').exists() else ''
s=s.replace('</style>',css+'\n</style>',1)
hooks='''
if(testMode)Object.assign(window.__LAST_CLASS_TEST__,{ensure39,study39,make39,timeFlow39,metrics39,routeOptions39,showRoutes39,showSocial39,socialAction39,updateSocial39,beginDeep39,nextDeep39,deepEligible39,deepFail39,selectPE39,completeSport39,nextGrid39,scheduledEvents,dispatchEvent,dispatchContinuation,startSport,enterClass,enterCampusSlot,finishQuestion,completeRapid,failHide,finishFreeze,godDefeat,makeQuestionTiming38,settingChange,renderTutorial36,syncMobile39,localize39,updateCampus,
 get sports39(){return SPORTS39;},get sealedStages39(){return DEEP_STAGES39;},
 debug39(){return {state:!!S,study:study39(),lang:lang39(),mobile:save.settings.mobileMode,questions:QUESTION_CATALOG38.filter(x=>x.kind!=='route').length,grids:GRID_BANK37.length,endings:ENDING_IDS.length,achievements:ACHIEVEMENTS.length};}});
'''
s=s.replace('\n})();\n',hooks+'\n})();\n')
(out/'index.html').write_text(s,encoding='utf-8')
js=re.search(r'<script>([\s\S]*)</script>',s).group(1)
(W/'game39.js').write_text(js,encoding='utf-8')
print('HTML',len(s.encode()),'questions',sum(map(len,questions.values()))+len(grids)+196)
