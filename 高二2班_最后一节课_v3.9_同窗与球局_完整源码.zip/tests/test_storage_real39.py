"""Attempt real on-disk browser storage using the unmodified HTML at file://.
No localStorage shim, page.set_content or RAF replacement in this test.
"""
import json,tempfile,shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
from support import ROOT,CHROMIUM_BIN
out={'passed':False,'blocked':False,'test':'Close persistent Chromium context, reopen same local file, restore real saved timer'}
profile=Path(tempfile.mkdtemp(prefix='lastclass39-'))
url=(ROOT/'index.html').as_uri()+'?test=1&persist=1'
try:
 with sync_playwright() as p:
  c=p.chromium.launch_persistent_context(str(profile),executable_path=CHROMIUM_BIN,args=['--no-sandbox'])
  page=c.new_page();page.goto(url,wait_until='load',timeout=15000)
  if not page.evaluate('!!window.__LAST_CLASS_TEST__'):raise RuntimeError('Game did not load at file://; document: '+page.title())
  page.evaluate('''()=>{const T=window.__LAST_CLASS_TEST__;T.start('quick','normal');T.finishDialogue();T.enterCampus(T.timetable.findIndex(x=>x.lesson===4));T.finishDialogue();T.testClear37();T.state.v37.decks.english=[27];T.question('english');T.openModal('pause');T.autoSave('actual disk persistence');}''')
  before=page.evaluate('({c:__LAST_CLASS_TEST__.challenge,id:__LAST_CLASS_TEST__.state.runId})')
  c.close()
  c=p.chromium.launch_persistent_context(str(profile),executable_path=CHROMIUM_BIN,args=['--no-sandbox'])
  page=c.new_page();page.goto(url,wait_until='load',timeout=15000)
  page.evaluate('__LAST_CLASS_TEST__.continueGame()')
  after=page.evaluate('({c:__LAST_CLASS_TEST__.challenge,id:__LAST_CLASS_TEST__.state?.runId})')
  if after!=before:raise AssertionError({'before':before,'after':after})
  out['passed']=True;out['savedTotal']=before['c']['total'];out['savedRemaining']=before['c']['remaining'];c.close()
except Exception as e:
 out['error']=str(e)
 out['blocked']=('ERR_' in str(e) or 'did not load at file://' in str(e) or 'net::' in str(e))
finally:
 shutil.rmtree(profile,ignore_errors=True)
 (ROOT/'tests/storage_real39_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 print(json.dumps(out,ensure_ascii=False,indent=2))
 if not out['passed'] and not out['blocked']:raise SystemExit(1)
