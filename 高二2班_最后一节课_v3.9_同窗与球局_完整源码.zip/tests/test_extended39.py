from support import *
import support
BASE=ROOT/'tests/fixtures/v3.8.html'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CHROMIUM_BIN,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1280,'height':800},has_touch=True);h=Harness(ctx,False)
 def start(d='normal',study=False):
  h.fresh();h.ev(f'T.save.settings.studyMode={str(study).lower()};T.start("quick","{d}","day",39791);T.finishDialogue();')
 def free():h.ev('T.testClear37();T.state.phase="CAMPUS";T.state.campus.location="playground";T.state.v34.recess=null;T.state.v34.stand=0;T.state.discipline.standing=false;')
 def migrate(kind):
  current=support.SOURCE;support.SOURCE=BASE.read_text();h.fresh();support.SOURCE=current
  h.ev('T.start("quick","normal","day",1234);T.finishDialogue();')
  if kind=='PE':h.ev('T.testClear37();T.enterCampus(T.timetable.findIndex(x=>x.kind==="pe"));T.finishDialogue();T.startSport("run");T.advance(2);')
  else:h.ev('T.testClear37();T.enterCampus(T.timetable.findIndex(x=>x.lesson===5));T.finishDialogue();T.testClear37();'+('T.beginTest35();' if kind=='exam' else 'T.grid();')+'T.advance(1);')
  before=h.ev('T.autoSave("migration");return {id:T.state.runId,c:T.challenge,activity:T.state.campus.activity};');disk=h.page.evaluate('__disk')
  h.fresh(disk);h.ev('T.continueGame();');after=h.ev('return {id:T.state.runId,c:T.challenge,activity:T.state.campus.activity,study:T.state.v39.study};')
  ensure(before['id']==after['id'] and after['study'] and h.valid() is True,str(after))
  if kind!='PE':ensure(before['c']['remaining']==after['c']['remaining'] and before['c']['correct']==after['c']['correct'])
  else:ensure(before['activity']==after['activity'] and h.ev('return T.state.v39.pe.choice==="basketball";'))
 for k in ['exam','grid','PE']:h.run('Actual v3.8 snapshot migration / '+k,lambda k=k:migrate(k))
 start('god');free()
 def deep_stages():
  result=h.ev('T.beginDeep39();T.choose(0);let states=0;while(T.state.v39.deep.status==="active"&&states<15){const c=T.challenge;T.validateSnapshot(T.captureSnapshot());if(!c.deep39)throw Error("checkpoint trial marker absent");let before=T.state.godElapsed;T.advance(.1);if(T.state.godElapsed<=before)throw Error("trial clock stopped");if(c.type==="question"||c.type==="grid")T.number(c.correct);else if(c.type==="hide"){T.advance(c.grace+.01);while(T.challenge?.type==="hide"){const r=T.challenge;T.reflexInput(r.layout.indexOf(r.sequence[r.step]));}}else {for(let n=0;T.challenge?.type==="freeze"&&n<100;n++)T.advance(.1);}states++;}return {states,right:T.state.v39.deep.right,valid:T.validateSnapshot(T.captureSnapshot())!==null};')
  ensure(result['states']==14 and result['right']==14,str(result))
 h.run('All 14 sealed stages save validly and consume the God clock',deep_stages)
 h.run('God ending rejects insufficient actual phone use',lambda:ensure(not h.ev('return T.deepEligible39();')))
 start('god');free()
 def real_clock():
  h.ev('T.setAction("phone");for(let i=0;i<41;i++)T.advance(.25);T.safeHide();T.beginDeep39();T.choose(0);')
  r=h.ev('let steps=0;while(T.state.screen==="game"&&steps++<5000){const c=T.challenge;if(T.script){T.finishDialogue();continue;}if(T.modal){T.resume();continue;}if(!c&&T.state.v34.clean?.phase==="request"){if(!T.state.v34.task)T.v34Action("clean"+[0,1,2].find(x=>!T.state.v34.clean.done.includes(x)));T.advance(.1);continue;}if(c&&["question","grid","hide","freeze","wait"].includes(c.type)){if(c.type==="question"||c.type==="grid"){if(c.elapsed<1.2)T.advance(.2);else T.number(c.correct);}else if(c.type==="hide"){if(c.elapsed<c.grace)T.advance(.1);else T.reflexInput(c.layout.indexOf(c.sequence[c.step]));}else T.advance(.1);}else if(c?.type==="peSelect39"||c?.type==="pePartner39")T.choose(2);else{T.advance(.1);if(T.state.v39.deep.status==="complete")T.safeHide();}}return {id:T.state.endingId,time:T.state.godElapsed,steps,d:T.state.v39.deep,phone:T.state.totalPhone,wrong:T.state.questionWrong,fails:T.state.dangerFails,caught:T.state.caught,phoneCaught:T.state.phoneCaught,story:T.dialogue};')
  ensure(r['id']=='deepArchive39' and r['time']>=180,str(r))
 h.run('Full 180-second sealed ending without editing clock or answer stats',real_clock)
 start()
 h.run('Non-God free time cannot start a sealed attempt',lambda:(free(),ensure(h.ev('return T.beginDeep39();') is False)))
 # Route prerequisite predicates: test boundary and god guard, not fake playthrough evidence.
 start(study=True);free()
 def routes():
  data=h.ev('const v=T.state.v39,p=T.state.v34.peng,w=v.wang;T.save.settings.pengRoute=T.save.settings.wangRoute=true;p.affection=100;p.letters=3;p.chats=4;p.badminton=2;p.consent=true;v.pengConfirmed=true;v.pengDays=[0,1,2];v.pengTopics=["snack","boundary"];w.affection=100;w.letters=2;w.sport=2;w.discussed=["sport","boundary","rest"];w.consent=true;v.correct=Object.values(T.questions37).flat().slice(0,30).map(q=>q.id37);v.subjects=["chemistry","biology","physics","english","math"];v.gridLessons=["study:0:math"];v.sports=["badminton","basketball","pingpong"].map((sport,i)=>({sport,day:i,slot:String(i),partner:"solo"}));T.state.calendar.mode="week";T.state.calendar.day=6;const unlocked=T.routeOptions39();T.state.difficulty="god";const blocked=T.routeOptions39();return {unlocked,blocked};')
  ensure(all(x['ok'] for x in data['unlocked']) and all(not x['ok'] for x in data['blocked']),str(data))
 h.run('All nine new departure prerequisites and God-mode blocking',routes)
 start();free()
 def consent():
  h.ev('T.save.settings.wangRoute=true;const w=T.state.v39.wang;w.affection=54;w.letters=1;T.socialAction39("wang","consent","");')
  ensure(h.ev('return !T.challenge;'))
  h.ev('T.state.v39.wang.affection=60;T.socialAction39("wang","consent","");T.choose(1);')
  ensure(not h.ev('return T.state.v39.wang.consent;'))
  h.ev('T.socialAction39("wang","consent","");T.choose(0);');ensure(h.ev('return T.state.v39.wang.consent;'))
 h.run('Mutual confirmation respects thresholds and friendship refusal',consent)
 start();free()
 def intersave():
  h.ev('T.socialAction39("wang","chat","rest");T.updateSocial39(1.6);');snap=h.ev('return T.captureSnapshot();');before=h.ev('return T.state.v39.social.elapsed;');h.ev('T.restore('+json.dumps(snap,ensure_ascii=False)+');T.resume();');ensure(h.ev('return T.state.v39.social.elapsed;')==before)
  h.ev('T.updateSocial39(2.4);');ensure(h.ev('return T.state.v39.wang.chats===1;') and h.valid() is True)
 h.run('Unfinished conversation resumes and grants reward exactly once',intersave)
 start();h.run('Runtime character profile has female sports representative',lambda:ensure('王梓锐</td><td>女' in h.ev('return T.renderCharacters();')))
 for width,height in [(320,568),(390,844),(844,390)]:
  start('god');free();h.page.set_viewport_size({'width':width,'height':height});h.ev('T.settingChange({dataset:{setting:"mobileMode"},checked:true});T.beginDeep39();T.choose(0);T.render();')
  def layout():
   r=h.page.locator('#challengeCard').bounding_box();ensure(r['x']>=0 and r['x']+r['width']<=width+1,str(r));ensure(h.page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
   h.page.screenshot(path=str(ROOT/f'tests/phone_{width}_{height}_question.png'))
  h.run(f'Phone question readable without horizontal overflow / {width}x{height}',layout)
  def touch():
   h.ev('T.testClear37();T.state.phase="CLASS";T.state.dangerCooldown=0;T.danger();T.advance(.5);T.render();')
   for i in range(6):
    slot=h.ev('const c=T.challenge;return c.layout.indexOf(c.sequence[c.step]);')
    h.page.locator(f'#challengeCard [data-reflex-slot="{slot}"]').tap()
   ensure(h.ev('return !T.challenge||T.challenge.type!=="hide";'))
  h.run(f'Actual six-button touch response / {width}x{height}',touch)
 start()
 def scriptlang():
  h.ev('T.settingChange({dataset:{setting:"language"},value:"zh-TW"});T.render();')
  txt=h.page.locator('#actionDock').inner_text();ensure('聽課' in txt and '觀察' in txt,txt)
  h.ev('T.settingChange({dataset:{setting:"language"},value:"zh-CN"});T.render();')
  ensure('听课' in h.page.locator('#actionDock').inner_text())
 h.run('Traditional Chinese applies and reverses in live action controls',scriptlang)
 h.run('No unhandled extended-suite errors',lambda:ensure(not ERRORS,str(ERRORS)))
 b.close()
 out={'results':RESULTS,'pageErrors':ERRORS,'passed':sum(x['passed'] for x in RESULTS),'total':len(RESULTS)}
 (ROOT/'tests/extended39_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('RESULT',out['passed'],out['total'])
 if out['passed']!=out['total']:raise SystemExit(1)
