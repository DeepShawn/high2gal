from support import *
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=CHROMIUM_BIN,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1280,'height':800},has_touch=True);h=Harness(ctx,False)
 h.page=ctx.new_page();h.page.on('pageerror',lambda e:ERRORS.append(str(e)));h.page.set_content(SOURCE)
 h.run('Unmodified HTML boots without debug hooks',lambda:ensure(h.page.locator('#startQuick').is_visible() and h.page.evaluate('window.__LAST_CLASS_TEST__===undefined')))
 def menu():
  h.page.locator('#menuStudy39').check();ensure(h.page.locator('#menuStudy39').is_checked());h.page.locator('#menuStudy39').uncheck()
  h.page.locator('#menuExtra39 [data-u39="language"]').click();h.page.locator('[data-setting="language"]').select_option('en');ensure('Language, platform and study' in h.page.locator('#modalBody').inner_text());h.page.keyboard.press('Escape')
 h.run('Real menu toggles and English language select',menu)
 def tutorial():
  h.page.locator('#tutorialBtn36').click();ensure(h.page.locator('#learnNav36 [data-lesson36]').count()==18);ensure('DeepShawn' in h.page.locator('#learnContent36').inner_text());h.page.locator('[data-lesson36="sports39"]').click();ensure('Liu Hai' in h.page.locator('#learnContent36').inner_text());h.page.locator('#learnClose36').click()
 h.run('Real tutorial navigation and narrator',tutorial)
 def fullscreen():
  h.page.keyboard.press('Alt+Enter');h.page.wait_for_timeout(100);ensure(h.page.evaluate('!!document.fullscreenElement'));h.page.keyboard.press('Alt+Enter');h.page.wait_for_timeout(100);ensure(h.page.evaluate('!document.fullscreenElement'))
 h.run('Actual Fullscreen API on release HTML',fullscreen)
 def phone():
  h.page.keyboard.press('Escape');h.page.set_viewport_size({'width':390,'height':844});h.page.locator('#menuExtra39 [data-u39="mobile"]').click();ensure(h.page.locator('#phoneShell39').is_visible());h.page.screenshot(path=str(ROOT/'tests/raw_phone_menu.png'));h.page.locator('#startQuick').click();h.page.wait_for_timeout(600);ensure(h.page.locator('#menu').is_hidden());h.page.screenshot(path=str(ROOT/'tests/raw_phone_intro.png'))
 h.run('Real phone menu and start button',phone)
 # Engine regression checks use isolated test hooks after raw release checks.
 h.fresh()
 for depth,total in [(1,20),(2,400),(3,8902)]:
  h.run(f'International chess initial perft depth {depth}',lambda depth=depth,total=total:ensure(h.ev(f'const c=new T.SchoolChess();function perft(n){{if(!n)return 1;let sum=0;for(const m of c.legalMoves()){{c.push(m);sum+=perft(n-1);c.undo();}}return sum;}}return perft({depth});')==total))
 h.run('Chess king cannot move into attacked square',lambda:ensure(h.ev('const c=new T.SchoolChess("4k3/8/8/8/8/8/4r3/4K3 w - - 0 1");return c.inCheck()&&!c.move({from:"e1",to:"d2"});')))
 h.run('Chess four promotion choices remain available',lambda:ensure(h.ev('const c=new T.SchoolChess("7k/P7/8/8/8/8/8/7K w - - 0 1");return c.moves({square:"a7"}).length===4;')))
 def portraits():
  h.ev('T.openModal("characters");')
  box=h.page.locator('.portraits39 .peng-preview36').bounding_box();part=h.page.locator('.portraits39 .peng-portrait36').bounding_box()
  ensure(box['width']>100 and box['height']>=150 and part['x']>=box['x']-1 and part['y']>=box['y']-1 and part['x']+part['width']<=box['x']+box['width']+1,str((box,part)))
  ensure(h.page.locator('.portraits39 .wang-preview39').is_visible())
  h.page.screenshot(path=str(ROOT/'tests/characters39.png'))
 h.run('Distinct character portraits stay inside their own cards',portraits)
 h.run('No release or chess runtime errors',lambda:ensure(not ERRORS,str(ERRORS)))
 b.close()
 out={'results':RESULTS,'pageErrors':ERRORS,'passed':sum(x['passed'] for x in RESULTS),'total':len(RESULTS)}
 (ROOT/'tests/release39_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('RESULT',out['passed'],out['total'])
 if out['passed']!=out['total']:raise SystemExit(1)
