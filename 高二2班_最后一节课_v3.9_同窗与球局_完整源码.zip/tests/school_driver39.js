// Deterministic input-aware integration agent, not a model of human difficulty.
// Reads answers and threats; never edits resource values or forces success.
let steps=0,seen=new Set(),slots=[],last='',savedChecks=0,homeWindows=[],nightDay=-1;
while(T.state.screen==='game'&&steps++<260000){
 const s=T.state,c=T.challenge,key=s.calendar.day+':'+s.campus.cursor+':'+(s.v34.recess?'recess':s.v34.office?'office':s.phase);
 if(key!==last){slots.push(key);last=key;T.validateSnapshot(T.captureSnapshot());savedChecks++;}
 if(T.modal){T.resume();continue;}
 if(T.script){T.finishDialogue();continue;}
 if(c){seen.add(c.type);
   if(c.type==='peSelect39'||c.type==='pePartner39'){T.choose(c.type==='peSelect39'?s.calendar.day%3:2);continue;}
   if(c.type==='hide'){if(c.elapsed<c.grace)T.advance(c.grace-c.elapsed+.001);else T.reflexInput(c.layout.indexOf(c.sequence[c.step]));continue;}
   if(c.type==='freeze'||c.type==='wait'){T.advance(.2);continue;}
   if(c.type==='question'||c.type==='grid'){if(c.elapsed<c.total*READ_FRACTION){T.advance(Math.min(.25,c.total*READ_FRACTION-c.elapsed));continue;}T.number(c.correct);continue;}
   if(c.type==='fakeBell'){T.choose(1);continue;}
   if(c.type==='pack'){T.choose(0);continue;}
   if(c.type==='route'){if(c.elapsed<c.total*READ_FRACTION){T.advance(Math.min(.25,c.total*READ_FRACTION-c.elapsed));continue;}T.choose(c.correct);continue;}
   if(c.type==='sprint'){T.advance(.11);T.sprint();continue;}
   if(c.type==='mealPlan'){T.choose(1);continue;}
   if(c.type==='officeQuestion'){T.choose(0);continue;}
   if(c.type==='evidence37'){if(c.elapsed<3)T.advance(.25);else T.choose(0);continue;}
   if(c.type==='surrender37'){T.choose(0);continue;}
   if(c.type==='weekDay'){T.validateSnapshot(T.captureSnapshot());T.choose(0);continue;}
   if(c.type==='morningCollect34'||c.type==='morningReturn34'){T.choose(0);continue;}
   if(c.type==='chemBook34'||c.type==='chemOffice34'){
     if(c.workRemaining){T.advance(.25);continue;}
     if(s.v34.book.corrections>0)T.choose(0);else T.choose(c.type==='chemBook34'?1:2);continue;
   }
   if(c.type==='romanceReview34'||c.type==='toyReview34'){T.choose(1);continue;}
   T.advance(.25);continue;
 }
 if(s.phase==='HOME'){
   seen.add('HOME');const h=s.home,p=h.parent;
   if(nightDay!==s.calendar.day){nightDay=s.calendar.day;homeWindows.push(T.homeRules().reaction);}
   if(!p&&h.phoneSeconds<h.target){if(h.action!=='phone')T.homeAction('phone');}
   else if(h.action!=='sleep')T.homeAction('hide');
   T.advance(.2);continue;
 }
 if(s.v34.morning.phase==='work'){if(s.v34.morning.mode!=='self')T.v34Action('self');T.advance(.25);continue;}
 if(s.v34.clean?.phase==='request'){
   if(!s.v34.task)T.v34Action('clean'+[0,1,2].find(x=>!s.v34.clean.done.includes(x)));
   T.advance(.25);continue;
 }
 if(s.v34.recess){T.setAction('listen');T.advance(.25);continue;}
 if(s.phase==='CLASS'){
   if(s.v34.clean&&['approach','search'].includes(s.v34.clean.phase)){T.advance(.25);continue;}
   if(s.boredom>50){
     if(s.classIndex===2||s.classIndex===5){T.setAction('observe');T.observe('window');}
     else T.setAction('homework');
   }else if(s.boredom<20||s.action!=='homework'&&s.action!=='observe')T.setAction('listen');
 }else if(s.phase==='CAMPUS'&&T.timetable[s.campus.cursor].kind==='pe'&&!s.campus.activity&&s.campus.pe.done.length<3){T.safeHide();T.startSport(['run','ball','walk'].find(x=>!s.campus.pe.done.includes(x)));}
 T.advance(.25);
}
T.render();
return {ending:T.state.endingId,steps,slots,seen:[...seen],phase:T.state.phase,day:T.state.calendar.day,results:T.state.calendar.results,completed:T.state.campus.completed,duration:T.state.survival,savedChecks,homeWindows,stats:T.state.v34.stats,challenge:T.challenge};
