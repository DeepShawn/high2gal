const V39_ENDINGS={
  "pengRally39": {
    "type": "GOOD END · V3.9",
    "title": "球网这边的约定",
    "prose": "彭望梓把两支球拍并排放进包里。\n“明天还打吗？要先问我，不能替我答应。”\n你点头。她的猫耳轻轻转向你，蝶结发卡映着校门的灯。\n球网把比赛分成两边，却没有把你们的放学路分开。",
    "hint": "开启班长攻略；好感≥65、送信≥1、羽毛球≥2，完成课后双方确认。",
    "en39": {
      "title": "A Promise on This Side of the Net",
      "prose": "Peng puts the two rackets away side by side.\n“Shall we play tomorrow? Ask me first—do not decide for me.”\nYou nod. Her ears turn toward you, and the ribbon catches the light at the gate.\nThe net divides the court, not the walk home.",
      "hint": "Peng route on; affection ≥65, at least one letter and two badminton interactions; mutual after-school confirmation."
    }
  },
  "pengSnack39": {
    "type": "GOOD END · V3.9",
    "title": "留给你的那一份",
    "prose": "彭望梓先把自己的饭盒抱稳，才推来一个小纸袋。\n“这份本来就是你的，不用抢。”\n你们把分享和擅自拿走分得很清楚。\n她说，明天也会记得给你留一份。",
    "hint": "开启班长攻略；好感≥60、讨论分享与边界、至少3次专属对话，课后确认。",
    "en39": {
      "title": "A Portion Set Aside",
      "prose": "Peng holds her lunchbox close, then slides a small paper bag toward you.\n“This portion is yours. No need to steal it.”\nYou both know the difference between sharing and taking without asking.\nShe says she will set another portion aside tomorrow.",
      "hint": "Peng route on; affection ≥60, discuss sharing and boundaries, at least three special conversations; confirm after school."
    }
  },
  "pengStudy39": {
    "type": "GOOD END · V3.9",
    "title": "猫耳旁的订正页",
    "prose": "图书室的灯还亮着。彭望梓把订正页转向你。\n“不是替我写。你讲思路，我自己来。”\n你们各自完成了一半，再把彼此遗漏的条件圈出来。\n最后一行不再是答案，而是下一次一起复习的时间。",
    "hint": "学习模式及班长攻略开启；好感≥70、当周答对≥12题且覆盖3科、送信≥1，课后确认。",
    "en39": {
      "title": "Corrections Beside Cat Ears",
      "prose": "The library light is still on. Peng turns her corrections toward you.\n“Do not write it for me. Explain the idea; I will do the work.”\nYou each solve your own problems and point out overlooked conditions.\nThe final line records your next study meeting, not an answer.",
      "hint": "Study mode and Peng route on; affection ≥70, 12 correct answers in at least three subjects, one letter; confirm after school."
    }
  },
  "pengTomorrow39": {
    "type": "GOOD END · V3.9",
    "title": "七天后的回信",
    "prose": "星期日21:40。彭望梓拿出一封折了又展开的信。\n“我不是因为你一直问才答应的。我想清楚了。”\n你们约定先走完今晚，再认真对待下一周。\n她没有替你通关，也不再只是结局条件上的一个名字。",
    "hint": "全周第7日；开启班长攻略，好感≥85、送信≥3、互动发生在至少3天，课后确认。",
    "en39": {
      "title": "A Reply After Seven Days",
      "prose": "Sunday, 21:40. Peng brings out a letter folded and unfolded many times.\n“I am not agreeing because you kept asking. I have thought it through.”\nYou agree to finish tonight, then face next week thoughtfully.\nShe has not beaten the game for you; she is more than a name in a condition list.",
      "hint": "Day 7 of a week; Peng route on, affection ≥85, three letters, interactions on three different days; mutual confirmation."
    }
  },
  "wangFriend39": {
    "type": "GOOD END · V3.9",
    "title": "并肩热身",
    "prose": "王梓锐理了理青绿色运动头带。\n“压力，阿妈忒拉斯。跑不动就慢一点，我等你。”\n她把自己那份点心护在怀里，却把水瓶递过来。\n没有任何人代替你观察后门，但有人愿意和你一起走。",
    "hint": "与体委完成2次不同话题、一次体育合作；普通友情不要求开启攻略。",
    "en39": {
      "title": "Warming Up Together",
      "prose": "Wang straightens her teal sports headband.\n“Pressure, Amaterasu. Slow down when you need to; I will wait.”\nShe guards her own snack but offers you water.\nNobody watches every danger for you, but someone will walk beside you.",
      "hint": "Complete two different conversations and one sports partnership with Wang. Romance is not required."
    }
  },
  "wangPromise39": {
    "type": "GOOD END · V3.9",
    "title": "发令声之后",
    "prose": "王梓锐把你的信放进球拍套，猫耳微微抬起。\n“这次我认真回答：愿意。等下次不是上课的时候再说。”\n你们并肩走过操场。\n她仍旧抢先去拿最后一块饼干，这一次却先问了你。",
    "hint": "开启体委攻略；好感≥60、送信≥1、体育合作≥1、尊重边界，课后确认。",
    "en39": {
      "title": "After the Starting Call",
      "prose": "Wang slips your letter into her racket cover and lifts her ears.\n“My serious answer is yes. Let us talk when class is over.”\nYou walk across the sports ground together.\nShe reaches first for the last biscuit—then remembers to ask.",
      "hint": "Wang route on; affection ≥60, one letter, one sports partnership, respect her boundaries; after-school confirmation."
    }
  },
  "wangTrust39": {
    "type": "GOOD END · V3.9",
    "title": "不用一直替我看着",
    "prose": "王梓锐终于放心地趴在桌沿，青绿色夹片压住短发。\n“我也会困。你不能把自己的安全全部交给我。”\n你答应了。后来她主动坐到你旁边，把比赛计划摊开。\n猫耳听见的是一段可以信任的话，不是命令。",
    "hint": "开启体委攻略；好感≥85、送信≥2、完成边界与休息话题、两次体育合作，课后确认。",
    "en39": {
      "title": "You Need Not Watch for Me Forever",
      "prose": "Wang finally rests at her desk, a teal clip holding back her short hair.\n“I get tired too. You cannot make me responsible for all your safety.”\nYou agree. Later she joins you and unfolds a match plan.\nHer ears have heard a promise she can trust, not an order.",
      "hint": "Wang route on; affection ≥85, two letters, discuss boundaries and rest, two sports partnerships; mutual confirmation."
    }
  },
  "scholar39": {
    "type": "GOOD END · V3.9",
    "title": "把疑问带出教室",
    "prose": "DeepShawn收好讲义。\n“女神只是外号。真正有用的是你写下来的推理。”\n你把不会的问题留在手记里，而不是假装每道题都已经懂了。\n门外没有标准答案，但你知道该怎样继续学。",
    "hint": "学习模式；同周答对30道不同题、覆盖5科、至少一节5题56选一全部答对，21:40选择。",
    "en39": {
      "title": "Carry the Questions Outside",
      "prose": "DeepShawn puts away the notes.\n“Goddess is only a nickname. The reasoning you wrote down is what matters.”\nYou keep your unanswered questions instead of pretending to understand everything.\nThere is no answer key outside, but you know how to keep learning.",
      "hint": "Study mode; answer 30 distinct questions across five subjects, complete a five-grid math lesson without mistakes, then choose this at 21:40."
    }
  },
  "sportsAll39": {
    "type": "GOOD END · V3.9",
    "title": "三种球的星期天",
    "prose": "刘嗨在体育记录上画了三个勾：羽毛球、篮球、乒乓球。\n“不是每一种都要赢，认真完成就行。”\n两位猫耳同学争着收拍，最后还是一起抱走球筐。\n操场上的三条线，这一周终于都留下了你的脚步。",
    "hint": "同一全周完成羽毛球、篮球、乒乓球三种所选体育课，每种完成三轮；之后21:40选择。",
    "en39": {
      "title": "Three Games by Sunday",
      "prose": "Liu Hai checks three boxes: badminton, basketball, table tennis.\n“You do not have to win every game. Participate properly.”\nThe two cat-eared classmates argue over the rackets, then carry the basket together.\nThis week you have left footsteps on all three courts.",
      "hint": "Complete all three drill rounds in each of badminton, basketball and table tennis during one week; select at 21:40."
    }
  },
  "deepArchive39": {
    "type": "BAD SECRET END · NO ESCAPE",
    "title": "第181页",
    "prose": "第180秒，所有出口仍然回到了教室。\nDeepShawn没有说你通关了，只把实验记录翻到不存在的第181页。\n“八道化学，三道编号，两次反应，一次静止。没有涂改。”\n这一次，闭环没有吞掉你的名字。\n你仍被留在学校，但终于留下了一份完整的证词。",
    "hint": "仅神级：正式新周目向DeepShawn接封存课题；同次连续完成8道L3/L4化学、3道56选一、2次零误按六键快反、1次零误动静止；全周零答错零被抓零快反失败，完成手机实际使用10秒并坚持180秒。失败后回档不会抹除本次课题失败标记。不是成功离校。",
    "en39": {
      "title": "Page 181",
      "prose": "At second 180 every exit still returns to the classroom.\nDeepShawn does not claim you escaped, but turns the log to a nonexistent page 181.\n“Eight chemistry problems, three number locks, two reactions, one stillness test. No corrections.”\nThis time the loop does not erase your name.\nYou remain inside, but a complete record survives.",
      "hint": "God only: accept DeepShawn’s sealed challenge; complete 8 L3/L4 chemistry questions, 3 grids, 2 flawless six-key reactions and 1 flawless stillness test consecutively; no wrong answers, catches or failed reactions; use a phone for 10 actual seconds and survive to 180 seconds. A failed trial remains failed on retry. This is an archive ending, not an escape."
    }
  }
};
const V39_ACHIEVEMENTS=[
  {
    "id": "peBadminton39",
    "name": "第一拍",
    "desc": "完成羽毛球体育课三轮练习。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "First Rally",
      "desc": "Complete all three badminton drills."
    }
  },
  {
    "id": "peBasket39",
    "name": "篮筐之下",
    "desc": "完成篮球体育课三轮练习。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Under the Hoop",
      "desc": "Complete all three basketball drills."
    }
  },
  {
    "id": "pePing39",
    "name": "白球过网",
    "desc": "完成乒乓球体育课三轮练习。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Across the Small Net",
      "desc": "Complete all three table-tennis drills."
    }
  },
  {
    "id": "peBonus39",
    "name": "配合加成",
    "desc": "攻略开启后，与选定伙伴完成一次羽毛球体育课并获得加成。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "A Partnership Bonus",
      "desc": "Complete badminton with an enabled route partner and receive the bonus."
    }
  },
  {
    "id": "threeSports39",
    "name": "三种节奏",
    "desc": "同周完成三种体育项目。",
    "group": "同窗与学习",
    "target": 3,
    "hidden": false,
    "en39": {
      "name": "Three Rhythms",
      "desc": "Complete all three sports in one week."
    }
  },
  {
    "id": "wangTalk39",
    "name": "她也会认真回答",
    "desc": "与王梓锐完成第一次对话。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "She Answers Seriously",
      "desc": "Complete a conversation with Wang."
    }
  },
  {
    "id": "wangBoundary39",
    "name": "先问再拿",
    "desc": "完成体委的边界话题，尊重她的点心与猫耳。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Ask Before Taking",
      "desc": "Discuss boundaries with Wang; respect her food and ears."
    }
  },
  {
    "id": "wangLetter39",
    "name": "运动头带下的信",
    "desc": "开启体委攻略并实际送达一封情书。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "A Letter Beneath the Headband",
      "desc": "Enable Wang’s route and successfully deliver a letter."
    }
  },
  {
    "id": "wang60",
    "name": "不止望风",
    "desc": "体委好感达到60。",
    "group": "同窗与学习",
    "target": 60,
    "hidden": false,
    "en39": {
      "name": "More Than a Lookout",
      "desc": "Reach 60 affection with Wang."
    }
  },
  {
    "id": "peng85",
    "name": "认真的回信",
    "desc": "班长好感达到85。",
    "group": "同窗与学习",
    "target": 85,
    "hidden": false,
    "en39": {
      "name": "A Thoughtful Reply",
      "desc": "Reach 85 affection with Peng."
    }
  },
  {
    "id": "differentDays39",
    "name": "不是一天的热闹",
    "desc": "与班长互动发生在三天，不重复刷同一课间。",
    "group": "同窗与学习",
    "target": 3,
    "hidden": false,
    "en39": {
      "name": "More Than One Afternoon",
      "desc": "Interact with Peng on three different days."
    }
  },
  {
    "id": "studyFirst39",
    "name": "先看条件",
    "desc": "学习模式实际答对第一道正式学科题。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Read the Conditions",
      "desc": "Answer a formal subject question correctly in study mode."
    }
  },
  {
    "id": "study30",
    "name": "三十个理由",
    "desc": "学习模式答对30道不同题。",
    "group": "同窗与学习",
    "target": 30,
    "hidden": false,
    "en39": {
      "name": "Thirty Reasons",
      "desc": "Answer 30 distinct study-mode questions correctly."
    }
  },
  {
    "id": "study100",
    "name": "一百次推理",
    "desc": "学习模式答对100道不同题。",
    "group": "同窗与学习",
    "target": 100,
    "hidden": false,
    "en39": {
      "name": "One Hundred Reasons",
      "desc": "Answer 100 distinct study-mode questions correctly."
    }
  },
  {
    "id": "fiveSubjects39",
    "name": "五科同页",
    "desc": "正式答对覆盖五门非语文学科。",
    "group": "同窗与学习",
    "target": 5,
    "hidden": false,
    "en39": {
      "name": "Five Subjects, One Notebook",
      "desc": "Answer correctly in five non-Chinese subjects."
    }
  },
  {
    "id": "threeGrid39",
    "name": "三道编号锁",
    "desc": "完成同节数学课3道56选一且全对。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Three Number Locks",
      "desc": "Complete all three math number locks in one casual-mode lesson correctly."
    }
  },
  {
    "id": "fiveGrid39",
    "name": "五道编号锁",
    "desc": "学习模式完成同节数学课5道56选一且全对。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "Five Number Locks",
      "desc": "Complete all five number locks in one study-mode math lesson correctly."
    }
  },
  {
    "id": "deepTrial39",
    "name": "女神的封存题",
    "desc": "在神级正式接下DeepShawn的封存课题；教程不计。",
    "group": "同窗与学习",
    "target": 1,
    "hidden": false,
    "en39": {
      "name": "The Sealed Challenge",
      "desc": "Accept DeepShawn’s sealed challenge in a real God-mode run."
    }
  },
  {
    "id": "deepProof39",
    "name": "十四项见证",
    "desc": "无失误完成封存课题全部14个环节。",
    "group": "同窗与学习",
    "target": 14,
    "hidden": true,
    "en39": {
      "name": "Fourteen Pieces of Evidence",
      "desc": "Complete all 14 stages of the sealed challenge without a mistake."
    }
  },
  {
    "id": "all39",
    "name": "同窗的新页",
    "desc": "集齐本版48条结局档案；旧收集成就门槛不变。",
    "group": "同窗与学习",
    "target": 48,
    "hidden": false,
    "en39": {
      "name": "New Pages for the Class",
      "desc": "Collect all 48 ending records; earlier collection achievements keep their old thresholds."
    }
  }
];
